//index.js
//获取应用实例
const util = require("../../utils/api.js")
const app = getApp();
const times = require("../../utils/times.js")
Page({
  data: {
    messageResult: [],
    flag: true,
    gmtPush: '',
    messageType: '',
    page: 1,
    totalPage: 0,
    scrollTop: 0,
    scrollHeight: 0,
    isFirst: true,
    title: '',
    canIUse: wx.canIUse('button.open-type.getUserInfo')
  },
  onLoad: function (option) {
    console.log(option)
    let self = this;
    if (option.messageType == 50) {
      self.setData({
        messageType: option.messageType,
        title: '点赞通知'
      })
      self.refreshView = self.selectComponent("#refreshView");
      self.pageDataList(true, false)
    } 
  },
  onShow: function () {
    var self = this;
    if (self.data.isFirst) {
      self.setData({
        isFirst: false
      })
      return
    }
    wx.getStorage({
      key: 'isFollowClick',
      success: function (res) {
        console.log(res)
        if (res.data) {
          self.onPullDownRefresh()
        }
      },
    })
  },
  pageDataList: function (pullDown = false, reachBottom = false) {
    let that = this;
    let params = {
      "request": {
        "messageType": Number(that.data.messageType),
        "pageNo": that.data.page,
        "pageSize": 15
      }
    }
    util._request('/message/_messageTypeList', params, 'post').then(res => {
      if (res.code == 0) {
        let totalPages = res.preload.totalPageNum;
        let messageResult = res.preload.results;
        if (res.preload.results == '' || res.preload.results == null) {
          that.setData({
            flag: false
          })
        }
        for (let index in messageResult) {
          let gmtPush = messageResult[index].gmtPush;
          messageResult[index].gmtPushNew = times.friendlyDate(gmtPush);
        }
        if (pullDown) {//执行的是下拉
          that.endThePullRequest()//结束下拉刷新
          that.setData({
            messageResult: messageResult
          })
        } else {//执行的是上拉
          that.setData({
            messageResult: self.data.messageResult.concat(messageResult)
          })
        }
      } else if (res.code == -1) {
        that.dealTheCurrentPage()
        app.reInitData()
        if (pullDown) {
          that.endThePullRequest()
        }
      } else {
        that.dealTheCurrentPage()
        if (pullDown) {
          that.endThePullRequest()
        }
      }
    }).catch(e => {
      that.dealTheCurrentPage()
      if (pullDown) {
        that.endThePullRequest()
      }
    })
  },
  //结束下拉刷新相关操作
  endThePullRequest() {
    this.refreshView.stopPullRefresh();
  },
  //请求出错的时候，要对page-1
  dealTheCurrentPage() {
    let that = this
    that.data.page--;
    if (that.data.page <= 0) {
      that.data.page = 1;
    }
  },
  // 分享
  onShareAppMessage: function (res) {
    var that = this;
    return app.appShare();
  },
  // 下拉刷新
  onPullDownRefresh: function () {
    let self = this;
    self.data.page = 1;
    self.pageDataList(true, false)
  },

  //上拉加载
  onReachBottom() {
    let that = this
    that.data.page++;
    //首先判断是加载更多分类数据还是无分类的数
    that.pageDataList(false, true)
  },
  //点击去详情页
  // clickToDetail(e) {
  //   let item = e.currentTarget.dataset.item;
  //   console.log(item)
  //   let index = Number(item.pubType)
  //   switch (index) {
  //     case 0:
  //       //动态
  //       wx.navigateTo({
  //         url: '../dynamic/dynamic?pubId=' + item.pubId,
  //       })
  //       break;
  //     default:
  //       wx.navigateTo({
  //         url: '../problemDetail/problemDetail?pubId=' + item.pubId,
  //       })
  //       break;
  //   }
  // },
  //触摸开始
  handletouchstart: function (event) {
    this.refreshView.handletouchstart(event)
  },
  //触摸移动
  handletouchmove: function (event) {
    this.refreshView.handletouchmove(event)
  },
  //触摸结束
  handletouchend: function (event) {
    this.refreshView.handletouchend(event)
  },
  //触摸取消
  handletouchcancel: function (event) {
    this.refreshView.handletouchcancel(event)
  },
  //页面滚动
  onPageScroll: function (event) {
    this.refreshView.onPageScroll(event)
  },
})

