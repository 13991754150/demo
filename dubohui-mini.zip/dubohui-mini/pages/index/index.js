//index.js
//获取应用实例
const util = require("../../utils/api.js")
const app = getApp()
const times = require("../../utils/times.js")
const videoContext = wx.createVideoContext("myVideo");
Page({
  data: {
    categoryId: '',
    pageNum: 1,
    allPageNum: 0,
    userInfo: {},
    title: '大播汇',
    motto: '',
    mode: "scaleToFill",
    arr: [],
    indicatorDots: true,
    autoplay: true,
    interval: 2000,
    duration: 1000,
    imgArr: [],
    isFollow: true,
    publishResult: [],
    tenSelectList: [], //10个选择框
    showInput: 0,
    bannerImg: [], //轮播图
    loadMode: true,   // 上拉加载更多
    nomore:false,
    isFollowClick:false,
    hasUserInfo: false,
    canIUse: wx.canIUse('button.open-type.getUserInfo'),
    level:0,
    width:0,
    pubIdArr:[],
    shareReturn: 0,
    isPlayState: false,
    _index:0,
    fullScreen:false,
    videoSrc: '',
    videoContext:null,
    videoWidth:0,
    videoHeight:0,
    navHeight: 64,
    needMargT: true,
    lock: false,
  },
  //跳到活动详情页面
  activeClick:function(e){
    // console.log(e)
    wx.navigateTo({
      url: '../jumpHcontent/jumpHcontent?jumpLink=' +e.currentTarget.dataset.jumplink,
    })
    // this.pauseVideo()
  },
  onLoad:function(){
    let self = this;
    this.refreshView = this.selectComponent("#refreshView")
    //这里因为要求用户必须登录
    if(!app.token){
      self.selectComponent("#login").showLogin();
    }
    //请求首页的数据
    self.pageSHowList(true, false);
    self.shareBtn()
    //请求首页的分类
    this.tenSelectInfo();
    //请求首页的banner
    this.bannerList();
  },
  onShow: function(option) {
    if (app.token) {//如果用户已经登录了，将之前弹出的登录界面进行隐藏
      this.selectComponent("#login").close();
    }
    //如果数据源有信息的话，吧数组里面的时间刷新
    if (this.data.publishResult && this.data.publishResult.length > 0) {
      let allData = this.data.publishResult
      for (let index in allData) {
        let startAt = allData[index].startAt;
        let timeStamp = times.timeStamps(startAt);
        allData[index].srartAtTimes = times.friendlyDate(timeStamp);
      }
      this.setData({
        publishResult: allData, 
      })
    }
    //如果有人发布的话，请求最新的数据
    if (app.needHomeRequestData) {
      app.needHomeRequestData = false;
      this.data.categoryId = '';
      this.data.pageNum = 1;
      this.pageSHowList(true, false);
    }
    if (app.needFollowRequestData) {
      app.needFollowRequestData = false;
      this.data.categoryId = '';
      this.data.pageNum = 1;
      this.pageSHowList(true, false);
    }
    app.getNewsFun()
  },
  // 请求首页的发布数据
  pageSHowList: function (pullDown = false, reachBottom = false) {
    let self = this;
    // 首页信息发布列表
    let params = {
      "inEntry": {
        "pubType": 0
      },
      "page": {
        "pageSize": 20,
        "pageNum": self.data.pageNum,
        "sortBy": 1
      }
    }
    util._request('/dabohui/content/publishList', params, 'post').then(res => {
      if (res.code == 0) {
        //赋值总页数
        self.data.allPageNum = res.preload.totalPageNum;
        let publishResult = res.preload.results;
        let pubArr = [];
        // 日期转时间戳
        for (let index in publishResult) {
          let startAt = publishResult[index].startAt;
          let timeStamp = times.timeStamps(startAt);
          publishResult[index].srartAtTimes = times.friendlyDate(timeStamp);
          let avatar = publishResult[index].userInfo.avatar;
          if (!avatar || avatar.length == 0){
            publishResult[index].userInfo.avatar = "../../image/head.png"
          }
          let pubId = publishResult[index].pubDetail.pubId;
          pubArr.push(pubId)
        }
        if (pullDown) {//执行的是下拉
          self.endThePullRequest()//结束下拉刷新
          self.setData({
            publishResult: publishResult,
            pubIdArr: pubArr
          })
        } else {//执行的是上拉
          self.setData({
            pubIdArr: pubArr,
            publishResult: self.data.publishResult.concat(publishResult)
          })
        }
      } else if (res.code == -1) {
        if (pullDown) {
          self.endThePullRequest()//结束下拉刷新
        }
        self.dealTheCurrentPage()
        app.reInitData()
        this.selectComponent("#login").showLogin()
      } else {
        if (pullDown) {
          self.endThePullRequest()//结束下拉刷新
        }
        self.dealTheCurrentPage()
      }
    }).catch(e => {//请求出错
      if (pullDown) {
        self.endThePullRequest()//结束下拉刷新
      }
      self.endThePullRequest()//结束下拉刷新
      self.dealTheCurrentPage()
    })
  },
  //结束下拉刷新相关操作
  endThePullRequest() {
    this.refreshView.stopPullRefresh();
  },
  //请求出错的时候，要对page-1
  dealTheCurrentPage() {
    let that = this
    that.data.pageNum--;
    if (that.data.pageNum <= 0) {
      that.data.pageNum = 1;
    }
  },
  // 请求轮播图
  bannerList: function() {
    let self = this;
    let params = {
      "inEntry": {
        "bannerType": 1,
        "returnNumber": 100,
        "requestFrom": 40,
        "requestVer": "1.0.0"
      }
    }
    util._request('/content/banner/list', params, 'post').then(res => {
      if (res.code == 0) {
        self.setData({
          bannerImg: res.preload.results
        })
      } else if (res.code == -1) {
        app.reInitData()
        self.selectComponent("#login").showLogin()
      }
    }).catch(e => {//请求失败
      // console.log(e)
    })
  },
  // 请求首页分类信息
  tenSelectInfo: function() {
    let self = this;
    let params = {
      "searchEntry": {
        "keyword": ""
      }
    }
    util._request('/content/publishCategory/secondList', params, 'post').then(res => {
      if (res.code == 0) {
        self.setData({
          tenSelectList: res.preload.results
        })
      } else if (res.code == -1) {
        app.reInitData()
        self.selectComponent("#login").showLogin()
      }
    }).catch(e => {//请求出错
    })
  },
  // 点击分类选择
  organizationSelect: function(e) {
    this.data.pageNum = 1;
    // this.data.categoryId = e.currentTarget.dataset.id;
    this.setData({
      categoryId: e.currentTarget.dataset.id
    })
    this.requestCategoryPublishListData(true, false);
  },
  //请求分类的数据
  requestCategoryPublishListData(pullDown = false, reachBottom = false) {
    let self = this
    let params = {
      "inEntry": {
        "pubType": 0,
        "cateId": self.data.categoryId
      },
      "page": {
        "pageSize": 20,
        "pageNum": self.data.pageNum,
        "sortBy": 1
      }
    }
    util._request('/dabohui/content/publishCate', params, 'post').then(res => {
      if (res.code == 0) {
        for (let index in res.preload.results) {
          let startAt = res.preload.results[index].startAt;
          let timeStamp = times.timeStamps(startAt);
          res.preload.results[index].srartAtTimes = times.friendlyDate(timeStamp);
          let avatar = res.preload.results[index].userInfo.avatar;
          if (avatar == '') {
            res.preload.results[index].userInfo.avatar = "../../image/head.png"
          }
        }
        if (pullDown) {//执行的是下拉
          self.endThePullRequest()//结束下拉刷新
          self.setData({
            publishResult: res.preload.results
          })
        } else {//执行的是上拉
          self.setData({
            publishResult: self.data.publishResult.concat(res.preload.results)
          })
        }
      } else if (res.code == -1) {
        if (pullDown) {
          self.endThePullRequest()//结束下拉刷新
        }
        self.dealTheCurrentPage()
        app.reInitData()
        self.selectComponent("#login").showLogin()
      } else {
        if (pullDown) {
          self.endThePullRequest()//结束下拉刷新
        }
        self.dealTheCurrentPage()
      }
    }).catch(e => {//请求失败
      if (pullDown) {
        self.endThePullRequest()//结束下拉刷新
      }
      self.dealTheCurrentPage()
    })
  },
  // 点击进入他人首页
  otherIndex: function(e) {
    if (!app.token) {//要求用户登录
      this.selectComponent("#login").showLogin()
    } else {//跳转
      if (app.token) {
        if (e.currentTarget.dataset.userid == app.globalData.userInfo.userId) {//是自己的时候不做任何操作
        } else if (e.currentTarget.dataset.userid == 0){//匿名的时候不能查看
        } else{
          wx.navigateTo({
            url: '../personalHomePage/personalHomePage?userId=' + e.currentTarget.dataset.userid + "&avatar=" + e.currentTarget.dataset.avatar + '&isFollow=' + e.currentTarget.dataset.isfollow + '&nickname=' + e.currentTarget.dataset.nickname + '&level=' + e.currentTarget.dataset.level,
          })
        }
      }
    }
    // this.pauseVideo()
  },
  // 点击进入详情页
  dynamicClick: function(e) {
    if (this.data.lock) {
      return;
    }
    let pubId = e.currentTarget.dataset.dx.pubId;
    // let itemString = JSON.stringify(item)
    wx.navigateTo({
      url: '../dynamic/dynamic?pubId=' + pubId
    })
  },
  //点击进入详情页
  // dynamicClicks:function(e){
  //   let item = e.currentTarget.dataset.dx;
  //   let itemString = JSON.stringify(item)
  //   wx.navigateTo({
  //     url: '../dynamic/dynamic?pubItem=' + itemString
  //   })
  // },
  // 预览图片
  previewImg: function(e) {
    let self = this;
    let pubIndex = e.currentTarget.dataset.pubindex;
    var index = e.currentTarget.dataset.index;
    let imageUrls = self.data.publishResult[pubIndex].pubDetail.extend.photos;
    var arr = [];
    for (let index in imageUrls){
      let imgUrllist = imageUrls[index].url;
      imgUrllist=imgUrllist.replace('!list', '!detail')
      arr.push(imgUrllist)
    }
    wx.previewImage({
      current: imageUrls[index].url.replace('!list', '!detail'),
      urls: arr, 
      success: function(res) {
      },
      fail: function(res) {},
      complete: function(res) {},
    })
  },
  // 点赞
  thumbs_up: function(e) {
    let self = this;
    if (!app.token) {
      self.selectComponent("#login").showLogin()
    } else {
      let index = e.currentTarget.dataset.index;
      let publishResult = self.data.publishResult;
      for (let i in publishResult) {
        if (i == index) {
          if (publishResult[i].pubDetail.isPraise == 0) {
            let params = {
              "inEntry": {
                "bizId": e.currentTarget.dataset.pubid,
                "bizType": 0,
                "praiseType": true
              }
            }
            util._request('/content/comment/praise', params, 'post').then(res => {
              if (res.code == 0) {
                publishResult[i].pubDetail.praiseNum += 1;
                publishResult[i].pubDetail.isPraise = 1;
                self.setData({
                  publishResult: publishResult
                })
              } else {
                wx.showModal({
                  title: '提示',
                  content: res.message,
                })
              }
            }).catch(e => {})
          } else {
            let params = {
              "inEntry": {
                "bizId": e.currentTarget.dataset.pubid,
                "bizType": 0,
                "praiseType": false
              }
            }
            util._request('/content/comment/praise', params, 'post').then(res => {
              if (res.code == 0) {
                publishResult[i].pubDetail.praiseNum -= 1;
                if (publishResult[i].pubDetail.praiseNum < 0) {
                  publishResult[i].pubDetail.praiseNum = 0;
                }
                publishResult[i].pubDetail.isPraise = 0;
                self.setData({
                  publishResult: publishResult
                })
              } else {
                wx.showModal({
                  title: '提示',
                  content: res.message,
                })
              }
            }).catch(e => {})
          }
        }
      }
    }
  },
  // 关注接口
  showLogins: function(e) {
    if (app.token) {
      let self = this;
      let index = e.currentTarget.dataset.index;
      let isFollow = e.currentTarget.dataset.isfollow == 0;
      let followId = e.currentTarget.dataset.userid;
      if (isFollow) {
        let params = {
          "followEntry": {
            "followId": followId,
            "followRemark": "",
            "followType": 0
          }
        }
        util._request('/content/relation/follow', params, 'post').then(res => {
          if (res.code == 0) {
            wx.showToast({
              title: '关注成功',
              icon: "none",
              duration: 1000
            })
            app.needFollowRequestData = true;
            let publishResult = self.data.publishResult;
            for (let i in publishResult) {
              let one = publishResult[i];
              if (one.userId == followId) {
                if (isFollow) {
                  one.pubDetail.isFollow = 1;
                } else {
                  one.pubDetail.isFollow = 0;
                }
              }
            }
            wx.setStorage({
              key: 'isFollowClick',
              data: true,
            })
            self.setData({
              publishResult: publishResult,
            })
          }
        }).catch(e => {})
      } else {
        wx.showModal({
          title: '提示',
          content: '是否取消对该用户的关注',
          success:function(res){
            if(res.confirm){
              let params = {
                "followId": followId,
              }
              util._request('/content/relation/unFollow', params, 'post').then(res => {
                if (res.code == 0) {
                  wx.showToast({
                    title: '取消关注成功',
                  })
                  app.needFollowRequestData = true;
                  let publishResult = self.data.publishResult;
                  for (let i in publishResult) {
                    let one = publishResult[i];
                    if (one.userId == followId) {
                      if (isFollow) {
                        one.pubDetail.isFollow = 1;
                      } else {
                        one.pubDetail.isFollow = 0;
                      }
                    }
                  }
                  wx.setStorage({
                    key: 'isFollowClick',
                    data: true,
                  })
                  self.setData({
                    publishResult: publishResult
                  })
                }
              }).catch(e => {})
            }
          }
        })
      }
    } else {
      this.selectComponent("#login").showLogin()
    }
  },
  // 下拉刷新
  onPullDownRefresh: function() {
    let that = this;
    that.data.pageNum = 1;
    //把分类清零
    // this.data.categoryId = '';
    // this.setData({
    //   categoryId: ''
    // })
    //请求banner的数据
    that.bannerList();
    //请求分类数据
    that.tenSelectInfo();
    // 首页信息发布列表（这里注意下拉请求的是所有的分类）
    if (that.data.categoryId) {//请求分类
      that.requestCategoryPublishListData(true, false)
    } else {//请求所有数据
      that.pageSHowList(true, false)
    }
  },
  //上拉加载
  onReachBottom() {
    let that = this
    that.data.pageNum++;
    //首先判断是加载更多分类数据还是无分类的数据
    if (that.data.categoryId) {//请求分类
      that.requestCategoryPublishListData(false, true)
    } else {//请求所有数据
      that.pageSHowList(false, true)
    }
  },
  shareBtn: function (e) {
    let self = this;
    // let params = {
    //   "bizIds": self.data.pubIdArr
    // }
    // util._request('/content/publish/updateShare', params, 'post').then(res => {
    //   if (res.code == 0) {

    //   } else if (res.code == -1) {
    //   }
    // }).catch(e => {
    // })
  },
  // 分享
  onShareAppMessage: function(res) {
    var that = this;
    if (res.from === 'button') {
      let pubid = res.target.dataset.pubid;
        let params = {
          "bizIds": [pubid]
        }
        util._request('/content/publish/updateShare', params, 'post').then(res => {
          if (res.code == 0) {
            let publishResult = that.data.publishResult;
            for (let index in publishResult) {
              if (publishResult[index].pubId == pubid){
                publishResult[index].pubDetail.shareNum += 1;
                break;
              }
            }
            that.setData({
              publishResult: publishResult
            })
          } else if (res.code == -1) {
            console.log(22222)
          }
        }).catch(e => {//请求失败
        console.log(e)
        })
      return {
        title: "大播汇",
        path: "/pages/dynamic/dynamic?pubId=" + res.target.dataset.pubid + '&shareReturn=' + 1,
        success: function (res) {
          console.log(res)
        },
        fail: function (e) {
          console.log(e)
        }
      }; 
    } else if (res.from === 'menu'){
      console.log(2222222)
      return app.appShare();
    }
  },
  onTabItemTap(item) {
    let self = this;
    self.setData({
      categoryId:''
    })
    //请求首页的分类
    this.tenSelectInfo();
    //请求首页的banner
    this.bannerList();
    self.data.pageNum = 1;
    self.pageSHowList(true, false);
  },
  //触摸开始
  handletouchstart: function (event) {
    this.refreshView.handletouchstart(event)
  },
  //触摸移动
  handletouchmove: function (event) {
    this.refreshView.handletouchmove(event)
  },
  //触摸结束
  handletouchend: function (event) {
    this.refreshView.handletouchend(event)
  },
  //触摸取消
  handletouchcancel: function (event) {
    this.refreshView.handletouchcancel(event)
  },
  //页面滚动
  onPageScroll: function (event) {
    this.refreshView.onPageScroll(event);
  },
  myEventListener: function (e) {
    if (e.detail.loginSuccess){
      this.onLoad()
    }else{
      this.selectComponent("#login").showLogin();
    }
  },
  
  videoPlay:function(e){
    let videoSrc = e.currentTarget.dataset.src;
    //跳转到全屏播放页面
    wx.navigateTo({
      url: '/pages/videoFull/videoFull?src=' + videoSrc,
    })
  },
  myVideoEvent(e){
  },
  //长按复制
  copyContent:function(e){
    // this.setData({
    //   lock: true
    // })
  }
})