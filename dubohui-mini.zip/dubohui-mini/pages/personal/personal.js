//获取应用实例
const util = require("../../utils/api.js")
const app = getApp();
Page({
  data: {
    fansNum: '',
    followNum: '',
    avatarUrl: '',
    myPbulishNum: '',
    unreadQuantity:0,
    nickname:'',
    userInfo:'',
    level:0,
    defaultImg:'../../image/head.png',
    result:true
  },
  onLoad: function (option) {
    let self = this;
    if (!app.token) {
      self.selectComponent("#login").showLogin();
    }
    self.setData({
      userInfo: app.globalData.userInfo,
    })
    if (app.globalData.userInfo){
      self.setData({
        avatarUrl: app.globalData.userInfo.avatar,
        nickname: app.globalData.userInfo.nickname,
        level: app.globalData.userInfo.level
      })
    }
  },
  // 是否申请已经入驻
  apply:function(){
    let self = this;
    let params = {
    }
    util._request('/dabohui/member/getEnter', params, 'post').then(res => {
      if (res.code == 0) {
        let result = res.preload.result.examineStatus;
        self.setData({
          result: result
        })
      }
    }).catch(e => {})
  },
  onShow: function () {
    let self = this;
    if (app.token) {
      self.selectComponent("#login").close();
    }
    self.fansCount();//粉丝关注数量
    self.unreadNew();//未读消息
    self.publishNum();//发布数量
    self.apply();//申请入驻信息
    app.getNewsFun()
  },
  // 未读消息
  unreadNew: function () {
    let self = this;
    let params = {
    }
    util._request('/message/_messageUnreadQuantity', params, 'post').then(res => {
      if (res.code == 0) {
        let unreadQuantity = res.preload.result.unreadQuantity;
        self.setData({
          unreadQuantity: unreadQuantity
        })
        // if (unreadQuantity != 0){
        //   wx.showTabBarRedDot({
        //     index: 4,
        //   })
        // }else{
        //   wx.hideTabBarRedDot({
        //     index: 4,
        //   })
        // }
        
      } else if (res.code == -1) {
      }
    }).catch(e => {
      console.log(e)
    })
  },
  // 粉丝数量，关注数量
  fansCount: function () {
    let self = this;
    let params = {
    };
    util._request('/content/relation/numInfo', params, 'post').then(res => {
      if (res.code == 0) {
        if (res.preload.result.fansNum == 0){
          self.setData({
            fansNum:0
          })
        }else{
          self.setData({
            fansNum: res.preload.result.fansNum,
          })
        }
        if (res.preload.result.followNum == 0){
          self.setData({
            followNum: 0
          })
        }else{
          self.setData({
            followNum: res.preload.result.followNum
          })
        }
        
      } else if (res.code == -1) {
      }
    }).catch(e => {
      console.log(e)
    })
  },
  // 发布数量
  publishNum: function () {
    let self = this;
    let params = {
    };
    util._request('/content/publish/numInfo', params, 'post').then(res => {
      if (res.code == 0) {
        let results = res.preload.results;
        let allNum = null;
        if (results == [] || results == ''){
          allNum = 0
        }else{
          for (let index in results) {
            let nums = Number(results[index].number);
            allNum += nums;
          }
        }
        self.setData({
          myPbulishNum: allNum
        })
      } else if (res.code == -1) {
      }
    }).catch(e => {
      console.log(e)
    })
  },
  onTabItemTap(item) {
    let self = this;
    self.onLoad()
  },
  message: function () {
    wx.navigateTo({
      url: '../news/news',
    })
  },
  publishClick: function () {
    wx.navigateTo({
      url: '../myPublish/myPublish',
    })
  },
  fansNum: function () {
    wx.navigateTo({
      url: '../fansList/fansList?userId=' + app.globalData.userInfo.userId,
    })
  },
  followList: function () {
    wx.navigateTo({
      url: '../followList/followList?userId=' + app.globalData.userInfo.userId,
    })
  },
  // 分享
  onShareAppMessage: function (res) {
    if (res.from === 'button') {
    }
    return app.appShare();
  },
  application:function(e){
    let self = this;
    wx.navigateTo({
      url: '../authentication/authentication?result=' + e.currentTarget.dataset.result,
    })
  },
  myEventListener: function (e) {
    if (e.detail.loginSuccess) {
      this.onLoad();
      this.onShow()
    } else {
    }
  }
})
