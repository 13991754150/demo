//获取应用实例
const util = require("../../utils/api.js")
const app = getApp()
const times = require("../../utils/times.js")
Page({
  data: {
    result:[],
    flag:true,
    page: 1,
    totalPage: 0, 
    scrollTop: 0,
    scrollHeight: 0,
    canIUse: wx.canIUse('button.open-type.getUserInfo')
  },
  onLoad: function (option) {
    let userId = option.userId;
    let self= this;
    self.setData({
      userId:userId
    })
    self.refreshView = self.selectComponent("#refreshView");
    self.pageDataList(true,false);  
  },
  onShow:function(){
    var self = this;
    //判断用户有没有从其他地方关注
    // wx.getStorage({
    //   key: 'isFollowClick',
    //   success: function (res) {
    //     if (res.data) {
    //       self.onPullDownRefresh()
    //     }
    //   },
    // })
    // self.pageDataList(true, false);
  },
  // 页面数据
  pageDataList: function (pullDown = false, reachBottom = false){
    let self = this;
    let params = {
      "userIn": {
        "keyword": ""
      },
      "page": {
        "pageSize": 30,
        "pageNum": self.data.page,
        "sortBy": 1
      }
    };
    util._request('/content/relation/fansList', params, 'post').then(res => {
      if (res.code == 0) {
        let result = res.preload.results;
        let totalPages = res.preload.totalPageNum;
        if (result == null || result == '') {
          self.setData({
            flag: false
          })
        } else {
          // 日期转时间戳
          for(let index in result){
            let one = result[index];
            let startAt = one.createdAt;
            let timeStamp = times.timeStamps(startAt);
            one.srartAtTimes = times.friendlyDate(timeStamp);
            let avatar = result[index].avatar;
            if (avatar == '') {
              result[index].avatar = "../../image/head.png"
            }
          }
          if (pullDown){
            self.endThePullRequest()//结束下拉刷新
            self.setData({
              result: result
            })
          }else{
            self.setData({
              result: self.data.result.concat(result)
            })
          }
        }
      } else if (res.code == -1) {
        self.dealTheCurrentPage()
        app.reInitData()
      } else {
        self.dealTheCurrentPage()
      }
    }).catch(e => {
      if (pullDown) {
        self.endThePullRequest()
      }
      self.dealTheCurrentPage()
    })
  },
  followOtherUser:function(e){
    let self = this;
    if (e.currentTarget.dataset.isfriend == false){
      let self = this;
      let params = {
        "followEntry": {
          "followId": e.currentTarget.dataset.userid,
          "followRemark": "",
          "followType": 0
        }
      }
      util._request('/content/relation/follow', params, 'post').then(res => {
        if (res.code == 0) {
          wx.showToast({
            title: '关注成功',
          })
          wx.setStorage({
            key: 'isFollowClick',
            data: true,
          })
        }
        self.onPullDownRefresh()
      }).catch(e => {
      })
    }else{
      wx.showModal({
        title: '提示',
        content: '您是否要取消对该用户的关注',
        success:function(res){
          if(res.confirm){
            let params = {
              "followId": e.currentTarget.dataset.userid,
            }
            util._request('/content/relation/unFollow', params, 'post').then(res => {
              if (res.code == 0) {
                wx.showToast({
                  title: '取消关注成功',
                })

                wx.setStorage({
                  key: 'isFollowClick',
                  data: true,
                })
              }
              self.onPullDownRefresh()
            }).catch(e => {
            })
          }else{
          }
        }
      })
    }
    setTimeout(function(){
      let result = self.data.result;
      for (let i in result) {
        let one = result[i];
        if (one.userId == e.currentTarget.dataset.userid) {
          if (e.currentTarget.dataset.isfriend) {
            one.isFriend = false;
          } else {
            one.isFriend = true;
          }
        }
      }
      self.setData({
        result: result
      })
    },200)
  },
  // 分享
  onShareAppMessage: function (res) {
    var that = this;
    return app.appShare();
  },
  //结束下拉刷新相关操作
  endThePullRequest() {
    this.refreshView.stopPullRefresh();
  },
  //请求出错的时候，要对page-1
  dealTheCurrentPage() {
    let that = this
    that.data.page--;
    if (that.data.page <= 0) {
      that.data.page = 1;
    }
  },
  // 下拉刷新
  onPullDownRefresh: function () {
    let self = this;
    self.data.page = 1;
    self.pageDataList(true, false)
  },
  //上拉加载
  onReachBottom() {
    let that = this
    that.data.page++;
    //首先判断是加载更多分类数据还是无分类的数
    that.pageDataList(false, true)
  },
  //触摸开始
  handletouchstart: function (event) {
    this.refreshView.handletouchstart(event)
  },
  //触摸移动
  handletouchmove: function (event) {
    this.refreshView.handletouchmove(event)
  },
  //触摸结束
  handletouchend: function (event) {
    this.refreshView.handletouchend(event)
  },
  //触摸取消
  handletouchcancel: function (event) {
    this.refreshView.handletouchcancel(event)
  },
  //页面滚动
  onPageScroll: function (event) {
    this.refreshView.onPageScroll(event)
  },
  inOtherPage:function(e){
    wx.navigateTo({
      url: '../personalHomePage/personalHomePage?userId=' + e.currentTarget.dataset.userid + "&avatar=" + e.currentTarget.dataset.avatar + '&isFollow=' + e.currentTarget.dataset.isfollow + '&nickname=' + e.currentTarget.dataset.nickname,
    })
  }
})
