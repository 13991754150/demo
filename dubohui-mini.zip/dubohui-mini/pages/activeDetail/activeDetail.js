// pages/activeDetail/activeDetail.js
const util = require("../../utils/api.js")
const times = require("../../utils/times.js")
const app = getApp()
Page({
  data: {
    listData:[
      // { 'code': '原价', "time1": '5.10-6.10', "time2": '6.10-7.10', "time3": '6.10-7.10'},
      // { 'code': '999', "time1": '1999', "time2": '2999', "time3": '3999' },
    ],
    // list: [
    //   { id: 1, name: '做过', value: '做过', checked: false },
    //   { id: 2, name: '没做过', value: '没做过', checked: false },
    // ],
    // itemList: [
    //   { id: 1, name: '工厂', value: '做过', checked: false, },
    //   { id: 2, name: '档口', value: '档口', checked: false, },
    //   { id: 2, name: '淘宝店', value: '淘宝店', checked: false, },
    //   { id: 2, name: '天猫点', value: '天猫点', checked: false, }
    // ],
    // list1: [
    //   { id: 1, name: '参加', value: '参加', checked: false },
    //   { id: 2, name: '不参加', value: '不参加', checked: false },
    // ],
    showTrue:false,
    name:'',
    phone:'',
    city:'',
    items:'',
    job:'',
    select1:'',
    select2:'',
    select3:'',
    result:'',
    content:'',
    title:'',
    fields:[],
    inLimit:[],
    currentPrice:0,
    surprTime:'',
    photos:[]
  },
  onLoad:function(){
    let self = this;
    let params={
      "pubId": 20065301
    }
    util._request('/dabohui/content/eventDetail', params, 'post').then(res => {
      // console.log(JSON.stringify(res))
      if (res.code == 0) {
        let result = res.preload.result;
        let startAt = result.startAt;
        let closedAt = result.closedAt;
        let timeStamp1 = times.timeStamps(startAt);
        let timeStamp2 = times.timeStamps(closedAt);
        let timeList = (timeStamp2 / 1000) - (timeStamp1 / 1000);
        let surprTime = times.calculateDiffTime(timeList)

        self.setData({
          fields: result.pubDetail.extend.fields,
          listData: result.pubDetail.extend.prices,
          content: result.pubDetail.content,
          title: result.pubDetail.title,
          inLimit: result.pubDetail.inLimit,
          currentPrice: result.pubDetail.currentPrice,
          surprTime: surprTime,
          photos: result.pubDetail.extend.photos
        })
      }
    }).catch(e => { })
  },
  nameInput:function(e){
    let self = this;
    self.setData({
      name:e.detail.value
    })
  },
  phoneInput: function (e) {
    let self = this;
    self.setData({
      phone: e.detail.value
    })
  },
  cityInput: function (e) {
    let self = this;
    self.setData({
      city: e.detail.value
    })
  },
  itemsInput: function (e) {
    let self = this;
    self.setData({
      items: e.detail.value
    })
  },
  jobInput: function (e) {
    let self = this;
    self.setData({
      job: e.detail.value
    })
  },
  radioChange: function (e) {
    let self = this;
    self.setData({
      select1: e.detail.value
    })
  },
  checkboxChange(e) {
    let self = this;
    self.setData({
      select2: e.detail.value
    })
  },
  radioChange1: function (e) {
    let self = this;
    self.setData({
      select3: e.detail.value
    })
  },
  showMessage:function(){
    let self = this;
    self.setData({
      showTrue:!self.data.showTrue
    })
  },
  submit:function(){
    let self = this;
    var myreg = /^[1][3,4,5,7,8][0-9]{9}$/;//手机号正则判断
    if(self.data.name==''){
      wx.showToast({
        title: '姓名不能为空',
        icon:'none'
      })
      return
    }
    if (self.data.phone == '' || !myreg.test(self.data.poneContent)) {
      wx.showToast({
        title: '请填写正确的手机号',
        icon: 'none'
      })
      return
    }
    if (self.data.city == '') {
      wx.showToast({
        title: '城市不能为空',
        icon: 'none'
      })
      return
    }
    if (self.data.items == '') {
      wx.showToast({
        title: '类目不能为空',
        icon: 'none'
      })
      return
    }
    if (self.data.job == '') {
      wx.showToast({
        title: '职位不能为空',
        icon: 'none'
      })
      return
    }
    if (self.data.select1 == '') {
      wx.showToast({
        title: '请选择是否做过电商',
        icon: 'none'
      })
      return
    }
    if (self.data.select2 == '') {
      wx.showToast({
        title: '请选择商家类型',
        icon: 'none'
      })
      return
    }
    if (self.data.select3 == '') {
      wx.showToast({
        title: '请选择是否参加晚餐',
        icon: 'none'
      })
      return
    }
    let params={
      "eventEntry": {
        "userId":app.globalData.userInfo.userId,
        "openid": "uattslbbvubnlqul",
        "bizId": 2382996556278968000,
        "payFrom": 18,
        "requestFrom": 40,
        "valueList": [
          {
            "key": "zuyaerlgikxjbonl",
            "value": "vztoyzbrtbxncvgz"
          },
          {
            "key": "pihmgpmxtxwbbbmt",
            "value": "rsihlwhnqkcibnre"
          }
        ]
      }
    }
    util._request('/dabohui/content/eventDetail', params, 'post').then(res => {
      console.log(res)
    }).catch(e => {

    })
  }
})
