//获取应用实例
const util = require("../../utils/api.js");
const app = getApp();
const times = require("../../utils/times.js")
Page({
  data: {
    publishResult: [],
    scrollTop: 0,
    scrollHeight: 0,
    attention: '+关注',
    pageNum: 1,
    totalPage: 1,
    canIUse: wx.canIUse('button.open-type.getUserInfo'),
    pubIdArr: [],
    shareReturn: 0,
    isPlayState: false,
    videoSrc: '',
    videoContext: null,
    lock: false
  },
  // 加载更多函数
  loadMore: function (pullDown = false, reachBottom = false) {
    let self = this;
    let params = {
      "inEntry": {
        "pubType": 0,
      },
      "page": {
        "pageSize": 20,
        "pageNum": self.data.pageNum,
        "sortBy": 1
      }
    }
    util._request('/dabohui/content/publishLike', params, 'post').then(res => {
      if (res.code == 0) {
        let publishResult = res.preload.results;
        self.data.totalPageNum = res.preload.totalPageNum;
        let pubArr = [];
        // 日期转时间戳
        for (let index in publishResult) {
          let startAt = publishResult[index].startAt;
          let timeStamp = times.timeStamps(startAt);
          publishResult[index].srartAtTimes = times.friendlyDate(timeStamp);
          let avatar = publishResult[index].userInfo.avatar;
          if (avatar == '') {
            publishResult[index].userInfo.avatar = "../../image/head.png"
          }
          let pubId = publishResult[index].pubDetail.pubId;
          pubArr.push(pubId)
        }
        if (pullDown) {//下拉
          self.endThePullRequest()
          self.setData({
            publishResult: publishResult,
            pubIdArr: pubArr
          })
        } else {//加载更多
          self.setData({
            pubIdArr: pubArr,
            publishResult: self.data.publishResult.concat(publishResult)
          })
        }
      } else {
        if (pullDown) {
          self.endThePullRequest()
        }
        self.dealTheCurrentPage()
      }
    }).catch(e => {
      if (pullDown) {
        self.endThePullRequest()
      }
      self.dealTheCurrentPage()
    })
  },
  //结束下拉刷新相关操作
  endThePullRequest() {
    this.refreshView.stopPullRefresh();
  },
  //请求出错的时候，要对page-1
  dealTheCurrentPage() {
    let that = this
    that.data.pageNum--;
    if (that.data.pageNum <= 0) {
      that.data.pageNum = 1;
    }
  },
  onLoad:function(){
    this.refreshView = this.selectComponent("#refreshView")
    this.data.pageNum = 1;
    if (!app.token) {
      this.selectComponent("#login").showLogin();
    }
    // 加载数据
    this.loadMore(true, false);
    this.shareBtn()
  },
  onShow: function () {
    let self = this;
    if (app.token) {
      self.selectComponent("#login").close();
    }
    if (app.needFollowRequestData) {
      app.needFollowRequestData = false;
      self.data.pageNum = 1;
      self.loadMore(true, false);
    }
    app.getNewsFun()
  },
  // 他人主页
  otherIndex: function (e) {
    wx.navigateTo({
      url: '../personalHomePage/personalHomePage?userId=' + e.currentTarget.dataset.userid + "&avatar=" + e.currentTarget.dataset.avatar + '&isFollow=' + e.currentTarget.dataset.isfollow + '&nickname=' + e.currentTarget.dataset.nickname + '&level' + e.currentTarget.dataset.level,
    })
  },
  //点击进入详情
  dynamicClick: function (e) {
    if (this.data.lock) {
      return;
    }
    let pubId = e.currentTarget.dataset.item.pubId;
    // let itemString = JSON.stringify(item)
    wx.navigateTo({
      url: '../dynamic/dynamic?pubId=' + pubId
    })
  },
  // 关注
  showLogins: function (e) {
    if (app.token) {
      let self = this;
      let followId = e.currentTarget.dataset.userid;
      wx.showModal({
        title: '提示',
        content: '您是否取消对该用户的关注',
        success:function(res){
          if(res.confirm){
            let params = {
              "followId": followId,
            }
            util._request('/content/relation/unFollow', params, 'post').then(res => {
              if (res.code == 0) {
                wx.showToast({
                  title: '取消关注成功',
                })
                let publishResult = self.data.publishResult;
                let arr =[];
                for (let i in publishResult) {
                  let item = publishResult[i];
                  if (item.userId != followId) {
                    arr.push(publishResult[i])
                  }
                }
                self.setData({
                  publishResult: arr
                })
              }
            }).catch(e => { })
          }
        }
      })   
      // }
    } else {
      this.selectComponent("#login").showLogin()
    }
  },
  // 点赞
  thumbs_up: function (e) {
    let self = this;
    let index = e.currentTarget.dataset.index;
    let publishResult = self.data.publishResult;
    for (let i in publishResult) {
      if (i == index) {
        if (publishResult[i].pubDetail.isPraise == 0) {
          let params = {
            "inEntry": {
              "bizId": e.currentTarget.dataset.pubid,
              "bizType": 0,
              "praiseType": true
            }
          }
          util._request('/content/comment/praise', params, 'post').then(res => {
            if (res.code == 0) {
              publishResult[i].pubDetail.praiseNum += 1;
              publishResult[i].pubDetail.isPraise = 1;
              self.setData({
                publishResult: publishResult
              })
            } else if (res.code == 1) {
              wx.showModal({
                title: '提示',
                content: res.message,
              })
            }
          }).catch(e => {
          })
        } else {
          let params = {
            "inEntry": {
              "bizId": e.currentTarget.dataset.pubid,
              "bizType": 0,
              "praiseType": false
            }
          }
          util._request('/content/comment/praise', params, 'post').then(res => {
            if (res.code == 0) {
              if (publishResult[i].pubDetail.praiseNum == 0) {
                publishResult[i].pubDetail.praiseNum = 0
              } else {
                publishResult[i].pubDetail.praiseNum -= 1;
              }
              publishResult[i].pubDetail.isPraise = 0;
              self.setData({
                publishResult: publishResult
              })
            } else if (res.code == 1) {
              wx.showModal({
                title: '提示',
                content: res.message,
              })
            }
          }).catch(e => {
          })
        }
      }
    }
  },
  //预览图片
  previewImg: function (e) {
    let pubIndex = e.currentTarget.dataset.pubindex;
    var index = e.currentTarget.dataset.index;
    let item = this.data.publishResult[pubIndex];
    let imageUrls = item.pubDetail.extend.photos;
    var arr = [];
    for (let index in imageUrls) {
      let imgUrllist = imageUrls[index].url;
      imgUrllist = imgUrllist.replace('!list', '!detail')
      arr.push(imgUrllist)
    }
    wx.previewImage({
      current: imageUrls[index].url.replace('!list', '!detail'),     //当前图片地址
      urls: arr,               //所有要预览的图片的地址集合 数组形式
      success: function (res) { },
      fail: function (res) { },
      complete: function (res) { },
    })
  },
  // 下拉刷新
  onPullDownRefresh:function(){
    let self = this;
    self.data.pageNum = 1;
    self.loadMore(true, false);
  },
  //上拉加载
  onReachBottom() {
    let that = this
    that.data.pageNum++;
    //加载更多
    that.loadMore(false, true);
  },
  // 分享
  onShareAppMessage: function (res) {
    var that = this;
    if (res.from === 'button') {
      let pubid = res.target.dataset.pubid;
      let params = {
        "bizIds": [pubid]
      }
      util._request('/content/publish/updateShare', params, 'post').then(res => {
        if (res.code == 0) {
          let publishResult = that.data.publishResult;
          for (let index in publishResult) {
            if (publishResult[index].pubId == pubid) {
              publishResult[index].pubDetail.shareNum += 1;
              break;
            }
          }
          that.setData({
            publishResult: publishResult
          })
        } else if (res.code == -1) {
          console.log(22222)
        }
      }).catch(e => {//请求失败
        console.log(e)
      })
      return {
        title: "大播汇",
        path: "/pages/dynamic/dynamic?pubId=" + res.target.dataset.pubid+'&shareReturn=' + 1,
        success: function (a) {
          console.log(a)
        },
        fail: function (e) {
        }
      };
    } else if (res.from === 'menu') {
      return app.appShare();
    }
  },
  //点击刷新
  onTabItemTap(item) {
    this.data.pageNum = 1
    this.loadMore(true, false)
  },
  //触摸开始
  handletouchstart: function (event) {
    this.refreshView.handletouchstart(event)
  },
  //触摸移动
  handletouchmove: function (event) {
    this.refreshView.handletouchmove(event)
  },
  //触摸结束
  handletouchend: function (event) {
    this.refreshView.handletouchend(event)
  },
  //触摸取消
  handletouchcancel: function (event) {
    this.refreshView.handletouchcancel(event)
  },
  //页面滚动
  onPageScroll: function (event) {
    this.refreshView.onPageScroll(event)
  },
  myEventListener: function (e) {
    if (e.detail.loginSuccess) {
      this.onLoad()
    } else {
    }
  },
  shareBtn: function () {
    let self = this;
    // let params = {
    //   "bizIds": self.data.pubIdArr
    // }
    // util._request('/content/publish/updateShare', params, 'post').then(res => {
    //   if (res.code == 0) {

    //   } else if (res.code == -1) {
    //   }
    // }).catch(e => {//请求失败
    // })
  },
  videoPlay: function (e) {
    let videoSrc = e.currentTarget.dataset.src;
    //跳转到全屏播放页面
    wx.navigateTo({
      url: '/pages/videoFull/videoFull?src=' + videoSrc,
    })
  },
  //长按复制
  copyContent: function (e) {
    // this.setData({
    //   lock: true
    // })
  }
})
