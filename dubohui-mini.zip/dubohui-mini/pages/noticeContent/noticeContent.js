//index.js
//获取应用实例
const util = require("../../utils/api.js")
const app = getApp();
const times = require("../../utils/times.js")
Page({
  data: {
    messageResult:[],
    flag: true,
    gmtPush: '',
    messageType: '',
    page: 1,
    totalPage:0,   
    scrollTop: 0,
    scrollHeight: 0,
    isFirst: true,
    totalPageNum:0
  },
  onLoad: function (option) {
   let self = this;
    self.setData({
      messageType: option.messageType
    })
    self.refreshView = self.selectComponent("#refreshView");
    self.pageDataList(true,false)
  },
  onShow: function () {
    var self = this;
    if (self.data.isFirst) {
      self.setData({
        isFirst: false
      })
      return
    }
    wx.getStorage({
      key: 'isFollowClick',
      success: function (res) {
        console.log(res)
        if (res.data) {
          self.onPullDownRefresh()
        }
      },
    })
  },
  // 页面数据
  pageDataList: function (pullDown = false, reachBottom = false){
    let self = this;
    let params = {
      "request": {
        "messageType": Number(self.data.messageType),
        "pageNo": self.data.page,
        "pageSize": 20
      }
    }
    util._request('/message/_messageTypeList', params, 'post').then(res => {
      // console.log(JSON.stringify(res))
      if (res.code == 0) {
        let totalPage = res.preload.totalPageNum;
        let messageResult = res.preload.results;
        if (res.preload.results == '' || res.preload.results == null) {
          self.setData({
            flag: false
          })
        }
        for (let index in res.preload.results) {
          let gmtPush = res.preload.results[index].gmtPush;
          res.preload.results[index].gmtPushNew = times.friendlyDate(gmtPush);
        }
        if (pullDown) {//执行的是下拉
          self.endThePullRequest()//结束下拉刷新
          self.setData({
            messageResult: messageResult
          })
        } else {//执行的是上拉
          self.setData({
            messageResult: self.data.messageResult.concat(messageResult)
          })
        }
      } else if (res.code == -1) {
        if (pullDown) {
          self.endThePullRequest()
        }
        self.dealTheCurrentPage()
        app.reInitData()
      } else {
        if (pullDown) {
          self.endThePullRequest()
        }
        self.dealTheCurrentPage()
      }
    }).catch(e => {
      if (pullDown) {
        self.endThePullRequest()
      }
      self.dealTheCurrentPage()
    })
  },
  //结束下拉刷新相关操作
  endThePullRequest() {
    this.refreshView.stopPullRefresh();
  },
  //请求出错的时候，要对page-1
  dealTheCurrentPage() {
    let that = this
    that.data.page--;
    if (that.data.page <= 0) {
      that.data.page = 1;
    }
  },
  // 分享
  onShareAppMessage: function (res) {
    var that = this;
    return app.appShare();
  },
  // 下拉刷新
  onPullDownRefresh: function () {
    let self = this;
    self.data.page = 1;
    self.pageDataList(true, false)
  },
  //上拉加载
  onReachBottom() {
    let that = this
    // if (that.data.totalPage > that.data.totalPageNum) {
    //   return;
    // }
    that.data.page++;
    //首先判断是加载更多分类数据还是无分类的数
    that.pageDataList(false, true)
  },
  //触摸开始
  handletouchstart: function (event) {
    this.refreshView.handletouchstart(event)
  },
  //触摸移动
  handletouchmove: function (event) {
    this.refreshView.handletouchmove(event)
  },
  //触摸结束
  handletouchend: function (event) {
    this.refreshView.handletouchend(event)
  },
  //触摸取消
  handletouchcancel: function (event) {
    this.refreshView.handletouchcancel(event)
  },
  //页面滚动
  onPageScroll: function (event) {
    this.refreshView.onPageScroll(event)
  },
})
