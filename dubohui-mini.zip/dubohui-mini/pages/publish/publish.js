const util = require("../../utils/api.js");
const utils = require("../../utils/util.js");
const oos = require("../../utils/aliyun-oss-sdk.min.js");
var QQMapWX = require('../../utils/qqmap-wx-jssdk.min.js');
var qqmapsdk;
const app = getApp();
// 
Page({
  data: {
    pics: [],
    // showPrblem: true,//是否显示问题发布
    classifys: true,//分类选择弹窗是否显示
    items: [],//具体的分类数据
    classifyName: '',//当前选中的分类
    classifyNames: '分类选择',//具体选择的分类名字
    latitude: "0", //维度，浮点数
    longitude: "0", //经度，浮点数
    content: '',//输入框内容
    contents: '',//问题输入内容
    address: '',
    show: false, //页面内容显示和隐藏
    touchStartTime: 0,//触摸开始时间
    touchEndTime: 0,// 触摸结束时间
    integer: [],//选择商家id
    arr: [],
    isAnonymous: false,//是否匿名
    isAnonymousQuestion: false,//是否匿名
    isOpenAddress: true,//是否打开位置
    maxlengths: 150,
    inputTextLength:0,//动态的长度
    inputTextLengthQuestion: 0,//问题长度
    isDynamic:true,
    autoFocus: false,//是否获取焦点
    displayAnonymous:true,// 控制版本号
    videoObj:null,
    isPlayState: false,
    videoSrc: '',
    videoCover:'',
    //管理图片数组
    originImageArray: []
  },
  onLoad: function (options) {
    if (!app.token) {
      this.selectComponent("#login").showLogin();
    }
    this.versionFun();
  },
  onShow: function () {
    if (app.token) {
      this.selectComponent("#login").close();
    }
    app.getNewsFun()
  },
  // 选择图片上传
  chooseImage: function () {
    var _this = this;
    _this.setData({
      videoObj:null
    })
    let originPicsArray = _this.data.originImageArray;
    wx.chooseImage({
      count: 9 - originPicsArray.length,
      sizeType: ['original', 'compressed'], // original 原图，compressed 压缩图，默认二者都有
      sourceType: ['album', 'camera'], // album 从相册选图，camera 使用相机，默认二者都有
      success: function (res) {
        let selectImageArray = res.tempFilePaths;
        var needToUploadArr = []
        for (let index in selectImageArray) {
          let obj = {}
          wx.getImageInfo({
            src: selectImageArray[index],
            success(res) {
              obj.uploadStatus = 1,//0默认状态 1上传中  2 上传成功 3上传失败
              obj.localUrl = selectImageArray[index],//本地地址
              obj.url = null,//网络地址
              obj.width = res.width,//宽度
              obj.height = res.height//高度
            }
          })
          //添加进数据源
          needToUploadArr.push(obj)
          _this.data.originImageArray.push(obj);
        }
        //绑定到UI
        _this.setData({
          originImageArray: _this.data.originImageArray
        })
        //开始上传图片
        _this.uploadImg(true, needToUploadArr)
      },
      fail: function () {
      },
      complete: function () {
      }
    })
  },
  // 上传图片获取路径的函数
  uploadImg: function (chooseImg, needToUploadImage) {
    let self = this;
    let params = {};
    util._request('/platform/upload/limitAuth', params, 'post').then(res => {
      let baseUrl = res.preload.baseUrl.replace('http://', 'https://');
      let times = new Date().getTime();
      if (chooseImg) {
        for (let i = 0; i < needToUploadImage.length; i++) {
          let name = res.preload.filePrefix + times + i;
          self.uploadTheImageWithIndex(res, i, name, needToUploadImage[i].localUrl, baseUrl);
        }
      }else{
        let name = res.preload.filePrefix + times;
        self.uploadVideoFun(res,name,times, baseUrl);
      }     
    }).catch(e => {
      for (let i = 0; i < self.data.originImageArray.length; i++) {
        let localUrl = self.data.originImageArray[i].localUrl;
        for (let j = 0; j < needToUploadImage.length; j++) {
          let needUploadLocalUrl = needToUploadImage[j].localUrl;
          if (localUrl == needUploadLocalUrl) {
            self.data.originImageArray[i].url = null;
            self.data.originImageArray[i].uploadStatus = 3;//失败
            break;
          }
        }
      }
      //刷新UI
      self.setData({
        originImageArray: self.data.originImageArray,
        videoObj: null
      })
      wx.showToast({
        title: '网络异常，请检查网络后重试',
        icon: 'none',
      })
    })
  },
  //上传图片
  uploadTheImageWithIndex(res, index, name, localUrl, baseUrl, isVideoFace = false) {
    let self = this
    wx.showLoading({
      title: '图片上传中...',
      mask: true
    })
    wx.uploadFile({
      url: baseUrl,//开发者服务器 url
      filePath: localUrl,//要上传文件资源的路径
      name: 'file',//必须填file
      formData: {
        'key': name,
        'policy': res.preload.policy,
        'OSSAccessKeyId': res.preload.accessKeyId,
        'signature': res.preload.signature,
        'success_action_status': '200',
      },
      success: function (res) {
        wx.hideLoading()
        if (res.statusCode == 200) {
          if (!isVideoFace){//上传图片
            for (let i = 0; i < self.data.originImageArray.length; i++) {
              let url = self.data.originImageArray[i].localUrl
              if (url == localUrl) {//赋值网络地址,修改上传状态
                self.data.originImageArray[i].url = baseUrl + name;
                self.data.originImageArray[i].uploadStatus = 2;//成功
                
                break;
              }
            }
          }
          //刷新UI
          self.setData({
            originImageArray: self.data.originImageArray
          })
        } else {//失败的情况，如果是图片直接删除，封面的话，将视频置空，提示失败信息
          if (isVideoFace) {//视频封面
          } else {//图片
            for (let i = 0; i < self.data.originImageArray.length; i++) {
              let url = self.data.originImageArray[i].localUrl
              if (url == localUrl) {//赋值网络地址,修改上传状态
                self.data.originImageArray[i].url = null;
                self.data.originImageArray[i].uploadStatus = 3;//失败
                break;
              }
            }
            //刷新UI
            self.setData({
              originImageArray: self.data.originImageArray
            })
          }
        }
      },
      fail: function (err) {//上传失败
        wx.hideLoading()
        if (isVideoFace) {//视频封面
        } else {//图片
          for (let i = 0; i < self.data.originImageArray.length; i++) {
            let url = self.data.originImageArray[i].localUrl
            if (url == localUrl) {//赋值网络地址,修改上传状态
              self.data.originImageArray[i].url = null;
              self.data.originImageArray[i].uploadStatus = 3;//失败
              break;
            }
          }
          //刷新UI
          self.setData({
            originImageArray: self.data.originImageArray
          })
        }
      },
    })
  },
  // 删除选择的图片
  deleteImg: function (e) {
    let self = this;
    let index = e.currentTarget.dataset.index;
    wx.showModal({
    title: '提示',
    content: '确定要删除此图片？',
    success: function (res) {
      if (res.confirm) {
        //删除图片链接
        self.data.originImageArray.splice(index, 1);
        //刷新UI
          self.setData({
            originImageArray: self.data.originImageArray
          });
        }
      }
    })
  },
  //刷新图片
  refreshImg:function(e){
    let that = this;
    let refreshArr = []
    refreshArr.push(that.data.originImageArray[e.currentTarget.dataset.index])
    that.uploadImg(true, refreshArr )
  },
  //删除视频
  deleteVideo:function(){
    let self = this;
    wx.showModal({
      title: '提示',
      content: '确定要删除此视频',
      success:function(res){
        if(res.confirm){
          self.setData({
            videoObj: null,
          })
        }else{
        }
      }
    })
  },
  /// 按钮触摸开始触发的事件
  touchStart: function (e) {
    let self = this;
    self.setData({
      touchStartTime: e.timeStamp
    })
  },
  /// 按钮触摸结束触发的事件
  touchEnd: function (e) {
    let self = this;
    self.setData({
      touchEndTime: e.timeStamp
    })
  },
  // 图片预览
  previewImage: function (e) {
    let that = this;
    let index = e.currentTarget.dataset.index;
    let imgArr = []
    imgArr.push(that.data.originImageArray[index].localUrl)
    if (that.data.touchEndTime - that.data.touchStartTime < 350) {
      var current = e.currentTarget.dataset.src
      wx.previewImage({
        current: current,
        urls: imgArr
      })
    }
  },
  //输入框的监听事件
  bindTextAreaBlurs: function (e) {
    let self = this;
    if (self.data.isDynamic){//动态
      self.setData({
        content: e.detail.value,
        inputTextLength: e.detail.value.length
      })
    }else{
      self.setData({
        contents: e.detail.value,
        inputTextLengthQuestion: e.detail.value.length
      })
    }
  },
  //点击获取焦点
  onShowTextare: function () {
    this.setData({
      autoFocus: true
    })
  },
  loseFocus: function () {
    this.setData({
      autoFocus: false
    })
  },
  //点击完成
  onShowTexts: function () {
    this.setData({
      autoFocus: false
    })
  },
  classifyClick: function () {
    let self = this;
    self.setData({
      classifys: false,
      autoFocus: false,
      isVideoFace:false
    })
    let params = {
      "searchEntry": {
        "keyword": ""
      }
    }
    util._request('/dabohui/content/categoryList', params, 'post').then(res => {
      if (res.code == 0) {
        for (let index in res.preload.results) {
          let dataList = res.preload.results[index];
          if (null != self.data.integer && dataList.cateId == self.data.integer[0]) {
            dataList.checked = true;
          } else {
            dataList.checked = false;
          }
        }
        self.setData({
          items: res.preload.results,
        })
      }
    }).catch(e => {
      console.log(e)
    })
  },
  // 单选
  radioChange: function (e) {
    let self = this;
    self.setData({
      classifyName: e.detail.value,
    })
  },
  raionSelect: function (e) {
    let self = this;
    let arrs = []
    arrs.push(e.currentTarget.dataset.id)
    self.setData({
      arr: arrs
    })
  },
  // 单选确定,
  classifyBtn: function () {
    let self = this;
    self.setData({
      classifys: true,
      classifyNames: this.data.classifyName,
      // color: '#000',
      autoFocus: false,
      integer: self.data.arr
    })
  },
  //取消
  cancelBtn: function () {
    let self = this;
    if (self.data.integer == [] || self.data.integer ==''){
      self.setData({
        classifys: true,
        classifyNames: '分类选择',
        // color: 'rgb(179,179,179)',
      })
    }else{
      self.setData({
        classifys: true,
        classifyNames: self.data.classifyNames,
        // color: '#000',
      })
    }
  },
  // 获取用户位置信息
  userAddress: function () {
    var self = this;
    if (self.data.isOpenAddress) {
      wx.chooseLocation({
        type: 'gcj02', // 默认为wgs84的gps坐标，如果要返回直接给openLocation用的坐标，可传入'gcj02'
        altitude: true,
        success(res) {
          self.setData({
            address: res.name
          })
          self.setData({
            color2: '#000'
          })
        },
        fail: function (e) {
          self.secondAddress();
        }
      })
      self.data.isOpenAddress = false
    } else {
      // wx.hideLoading()
      self.setData({
        // isHide: true,
        address: '',
        color2: 'color:rgb(179,179,179)',
      })
      self.data.isOpenAddress = true
    }
  },
  // 拒绝定位授权后再次授权
  secondAddress: function () {
    wx.getSetting({
      success: function (res) {
        let statu = res.authSetting;
        if (!statu['scope.userLocation']) {
          wx.showModal({
            title: '是否授权当前位置',
            content: '小程序需要获取您当前的地理位置，请确认授权',
            success: function (res) {
              // wx.hideLoading()
              if (res.confirm) {
                wx.openSetting({
                  success: function (data) {
                    if (data.authSetting["scope.userLocation"] === true) {
                      wx.showToast({
                        title: '授权成功',
                        icon: 'success',
                        duration: 1000
                      })
                      wx.chooseLocation({
                        type: 'gcj02',
                        altitude: true,
                        success: function (res) {
                          self.setData({
                            address: res.name
                          })
                          self.setData({
                            color2: '#000'
                          })
                        },
                      })
                    } else {
                      wx.showToast({
                        title: '授权失败',
                        icon: 'none',
                        duration: 1000
                      })
                    }
                  }
                })
              }
            }
          })
        }
        else {
        }
      }
    })
  },
  // 页面切换
  switchSelect: function (e) {
    let index = Number(e.currentTarget.dataset.index)
    let that = this
    switch(index) {
      case 0://点击动态
        if (that.data.isDynamic) {
          return;
        }
      break;
      case 1://点击问题
      if (!that.data.isDynamic) {
        return;
      }
      break;
    }
    that.setData({
      isDynamic: !that.data.isDynamic
    })
  },
  // 匿名
  userIsHide: function () {
    let that = this;
    if (that.data.isDynamic) {
      that.setData({
        isAnonymous: !that.data.isAnonymous
      })
    } else {
      that.setData({
        isAnonymousQuestion: !that.data.isAnonymousQuestion
      })
    }
  },
  // 发布
  publishMessage: function () {
    let self = this;
    if (self.data.isDynamic) {//发布动态
      self.publishTheDynamic()
    } else {//发布问题
      self.publishTheQuestion()
    }
  },
  //发布动态
  publishTheDynamic() {
    let self = this
    if (self.data.content == '') {
      wx.showToast({
        title: '请输入内容',
        icon: 'none'
      })
      return
    }
    if (self.data.integer == '' || self.data.integer == null) {
      wx.showToast({
        title: '请选择分类',
        icon: 'none'
      })
      return
    }
    let photos = self.data.originImageArray;
    var uploadImageArray = [];
    if (photos == null || !photos){
      photos = []
    }else{
      for (let i = 0; i < photos.length; i++) {
        let photo = photos[i]
        if (photo.uploadStatus == 2) {//上传成功的图片
          uploadImageArray.push(photo)
        }
      }
    }
    let videoObj = self.data.videoObj;
    let video = {};
    if (videoObj == null || !videoObj){
      video = null
    }else{
      video.cover = self.data.videoCover;
      video.url = self.data.videoObj.tempFilePathUrl;
      video.duration = self.data.videoObj.duration;
      video.size = self.data.videoObj.size;
      video.width = self.data.videoObj.width;
      video.height = self.data.videoObj.height;
    }
    console.log(uploadImageArray)
    let params = {
      "publishEntry": {
        "rootId": null,
        "pubGeo": {
          "latitude": String(self.data.latitude),
          "longitude": String(self.data.longitude)
        },
        "pubCity": null,
        "pubType": 0,
        "pubDetail": {
          "title": "",
          "content": self.data.content,
          "extend": {
            "photos":uploadImageArray,
            "video": video
          },
          "location": self.data.address
        },
        "topicList": [],
        "cateList": self.data.integer,
        "blackList": [],
        "accessType": 0,
        "limitType": 0,
        "creditType": 0,
        "creditNeed": 0,
        "isHide": self.data.isAnonymous
      }
    }
    util._request('/dabohui/content/publish', params, 'post').then(res => {
      if (res.code == 0) {
        wx.showToast({
          title: '提示',
          content: '发布成功',
        })
        self.updateLocalMessage()
        app.needHomeRequestData = true;
        wx.switchTab({
          url: '../index/index',
        })
      } else {
        wx.showToast({
          icon: 'none',
          title: res.message
        })
      }
    }).catch(e => {
      console.log(e)
    })
  },
  //发布问题
  publishTheQuestion() {
    let self = this
    if (self.data.contents == '') {
      wx.showToast({
        title: '请输入内容',
        icon: 'none'
      })
      return
    }
    let params = {
      "publishEntry": {
        "rootId": null,
        "pubGeo": {
          "latitude": String(self.data.latitude),
          "longitude": String(self.data.longitude)
        },
        "pubCity": null,
        "pubType": 1,
        "pubDetail": {
          "title": "",
          "content": self.data.contents,
          "extend": {
            "photos": []
          },
          "location": ''
        },
        "topicList": [],
        "cateList": self.data.integer,
        "blackList": [],
        "accessType": 0,
        "limitType": 0,
        "creditType": 0,
        "creditNeed": 0,
        "isHide": self.data.isAnonymousQuestion
      }
    }
    util._request('/dabohui/content/publish', params, 'post').then(res => {
      if (res.code == 0) {
        wx.showToast({
          title: '提示',
          content: '发布成功',
        })
        self.updateLocalMessage()
        app.needHomeRequestData = true;
        wx.switchTab({
          url: '../ansower/ansower',
        })
        wx.setStorage({
          key: 'isPublish',
          data: true,
        })
      } else {
        wx.showToast({
          icon: 'none',
          title: res.message
        })
      }
    }).catch(e => {
      wx.showToast({
        title: '网络出错',
        icon: 'none',
      })
    })
  },
  //更新本地数据
  updateLocalMessage() {
    this.setData({
      pics: [],
      // showPrblem: true,//是否显示问题发布
      classifys: true,//分类选择弹窗是否显示 true隐藏 false显示
      items: [],//具体的分类数据
      classifyName: '',//当前选中的分类
      classifyNames: '分类选择',//具体选择的分类名字
      latitude: "0", //维度，浮点数
      longitude: "0", //经度，浮点数
      content: '',//输入框内容
      contents: '',//问题输入内容
      address: '',
      show: false, //页面内容显示和隐藏 true隐藏  false显示
      touchStartTime: 0,//触摸开始时间
      touchEndTime: 0,// 触摸结束时间
      integer: [],//选择商家id
      arr: [],
      isAnonymous: false,//是否匿名
      isAnonymousQuestion: false,//是否匿名
      isOpenAddress: true,//是否打开位置 true是关 false是开
      maxlengths: 150,
      inputTextLength: 0,//动态的长度
      inputTextLengthQuestion: 0,//问题长度
      isDynamic: true,
      autoFocus: false,//是否获取焦点
      videoObj: null,
      isPlayState: false,
      videoSrc: '',
      videoCover: '',
      originImageArray: []//清空图片数据源
    })
  },
  // 分享
  onShareAppMessage: function (res) {
    var that = this;
    return app.appShare();
  },
  myEventListener: function (e) {
    if (e.detail.loginSuccess) {
      this.onLoad()
    } else {
    }
  },
  // 获取版本号
  versionFun:function(){
    let self = this;
    let params={
      "model": 3
    }
    util._request('/platform/version/coupon', params, 'post').then(res => {
      if(res.code == 0){
        let version = Number(res.preload.version);
        if (version <= 9){
          self.setData({
            displayAnonymous:false
          })
        }
      }
    }).catch(e => {

    })
  },
  //选择视频
  chooseVideo:function(){
    let self = this;
    if (self.data.originImageArray.length > 0){
      wx.showModal({
        title: '提示',
        content: '图片和视频不能同时上传',
        showCancel:false,
        success:function(res){
          if(res.confirm){
            self.setData({
              videoObj:null
            })
          }
        }
      })
      return
    }
    wx.chooseVideo({
      sourceType: ['album', 'camera'],
      maxDuration: 60,
      compressed:true,
      camera: 'back',
      success(res) {
        let videoObj = res;
        self.setData({
          videoObj: videoObj,
        })
        self.uploadImg(false,videoObj)
      },
      fail: function (e) {
      },
      complete: function (e) {
      }
    })
  },
  //上传视频
  uploadVideoFun: function (res,name,times, baseUrl){
    let self = this;
    wx.showLoading({
      title: '视频上传中...',
      mask:true
    })
    let uploadVideoPath = self.data.videoObj;
    let localVideourl = uploadVideoPath.tempFilePath;
    wx.uploadFile({
      url: baseUrl,
      filePath: uploadVideoPath.tempFilePath,
      name: 'file',
      formData: {
        'key': name,
        'policy': res.preload.policy,
        'OSSAccessKeyId': res.preload.accessKeyId,
        'signature': res.preload.signature,
        'success_action_status': '200',
      },
      success(res) {
        wx.hideLoading()
        if (res.statusCode == 200) {
          uploadVideoPath.tempFilePathUrl = baseUrl + name;
          self.setData({
            videoObj: uploadVideoPath
          })
          self.getVideoCover()
        }else{
          wx.showModal({
            title: '提示',
            content: '上传视频失败,请重新上传',
            showCancel: false,
            success: function (res) {
              if (res.confirm) {
                self.setData({
                  videoObj: null,
                })
              }
            }
          })
        }
      },
      fail:function(e){
        wx.hideLoading()
        wx.showModal({
          title: '提示',
          content: '上传视频失败',
          success:function(res){
            if(res.confirm){
              self.setData({
                videoObj: null,
              })
            }
          }
        })
      }
    })
  },
  ///获取视频封面
  getVideoCover:function(){
    let self = this;
    let params = {
      "video": {
        "url": self.data.videoObj.tempFilePathUrl,
      }
    }
    util._request('/content/publish/uploadCover', params, 'post').then(res => {
      if (res.code == 0) {
        let videoCover = res.preload.result;
        self.setData({
          videoCover: videoCover
        })
      }
    }).catch(e => {
    })
  },
  playVideo:function(e){
    console.log(e)
    let videoSrc = e.currentTarget.dataset.src;
    //跳转到全屏播放页面
    wx.navigateTo({
      url: '/pages/videoFull/videoFull?src=' + videoSrc,
    })
  },
  actionSheetTap: function () {
    let self = this;
    wx.showActionSheet({
      itemList: ['选择图片', '选择视频'],
      success(res) {
        if (res.tapIndex == 0){
          self.chooseImage()
        } else if (res.tapIndex == 1){
          self.chooseVideo()
        }
      },
      fail(res) {     
      }
    })
  },
  // actionSheetbindchange: function () {
  //   this.setData({
  //     actionSheetHidden: !this.data.actionSheetHidden
  //   })
  // },
})