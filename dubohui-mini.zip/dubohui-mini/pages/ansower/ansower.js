//获取应用实例
const util = require("../../utils/api.js");
const app = getApp()
const times = require("../../utils/times.js")

Page({
  data: {
    problemResult: [],
    attention: '解惑',
    page: 1,
    totalPage: 0, 
    lock: false
  },
  // 加载数据
  loadMore: function (pullDown = false, reachBottom = false){
    let self = this;
    let paramsPro = {
      "inEntry": {
        "pubType": 1
      },
      "page": {
        "pageSize": 20,
        "pageNum": self.data.page,
        "sortBy": 1
      }
    }
    util._request('/dabohui/content/publishList', paramsPro, 'post').then(res => {
      if (res.code == 0) {
        let problemResult = res.preload.results;
        let totalPage = res.preload.totalPageNum;
        // 日期转时间戳
        for (let index in problemResult) {
          let startAt = problemResult[index].startAt;
          let timeStamp = times.timeStamps(startAt);
          problemResult[index].srartAtTimes = times.friendlyDate(timeStamp);
          let avatar = problemResult[index].userInfo.avatar;
          if (avatar == '') {
            problemResult[index].userInfo.avatar = "../../image/head.png"
          }
        }
        if (pullDown) {//执行的是下拉
          self.endThePullRequest()//结束下拉刷新
          self.setData({
            problemResult: problemResult
          })
        } else {//执行的是上拉
          self.setData({
            problemResult: self.data.problemResult.concat(problemResult)
          })
        }
      }else if(res.code == -1){
        if (pullDown) {
          self.endThePullRequest()
        }
        self.dealTheCurrentPage()
        app.reInitData()
        self.selectComponent("#login").showLogin();
      }else{
        if (pullDown) {
          self.endThePullRequest()
        }
        self.dealTheCurrentPage()
      }
    }).catch(e => {
      if (pullDown) {
        self.endThePullRequest()
      }
      self.dealTheCurrentPage()
    })
  },
  onLoad: function () {
    let self = this;
    this.data.page = 1;
    this.refreshView = this.selectComponent("#refreshView");
    if (!app.token) {
      self.selectComponent("#login").showLogin();
    }
    self.loadMore(true,false);
  },
  onShow: function () {
    let self = this;
    if (app.token) {//如果用户已经登录了，将之前弹出的登录界面进行隐藏
      self.selectComponent("#login").close();
    }
    //如果数据源有信息的话，吧数组里面的时间刷新
    if (self.data.problemResult && self.data.problemResult.length > 0) {
      let allData = self.data.problemResult
      for (let index in allData) {
        let startAt = allData[index].startAt;
        let timeStamp = times.timeStamps(startAt);
        allData[index].srartAtTimes = times.friendlyDate(timeStamp);
      }
      self.setData({
        problemResult: allData
      })
    }
    if (app.needHomeRequestData){
      app.needHomeRequestData = false;
      self.data.page = 1;
      self.loadMore(true, false);
    }
    app.getNewsFun()
  },
  //结束下拉刷新相关操作
  endThePullRequest() {
    this.refreshView.stopPullRefresh();
  },
  //请求出错的时候，要对page-1
  dealTheCurrentPage() {
    let that = this
    that.data.page--;
    if (that.data.page <= 0) {
      that.data.page = 1;
    }
  },
  otherIndex: function (e) {
    console.log(e)
    let userInfo = e.currentTarget.dataset.userinfo;
    if (userInfo.userId == 0){//匿名
    } else if (userInfo.userId == app.globalData.userInfo.userId){//自己不做操作
     
    }else{
      wx.navigateTo({
        url: '../personalHomePage/personalHomePage?avatar=' + userInfo.userInfo.avatar + '&nickname=' + userInfo.userInfo.nickname + '&isFollow=' + userInfo.userInfo.isfollow + '&userId=' + userInfo.userInfo.userId,
      })
    }
  },
  problemClick: function (e) {
    if (this.data.lock) {
      return;
    }
    let pubId = e.currentTarget.dataset.datalist.pubId;
    // let itemString = JSON.stringify(e.currentTarget.dataset);
    wx.navigateTo({
      url: '../problemDetail/problemDetail?pubId=' + pubId,
    })
  },
  // 解惑
  showLogins: function (e) {
    let pubId = e.currentTarget.dataset.datalist.pubId;
    // let itemString = JSON.stringify(e.currentTarget.dataset);
    wx.navigateTo({
      url: '../problemDetail/problemDetail?pubId=' + pubId + '&index=' + e.currentTarget.dataset.index,
    })
  },
  // 下拉刷新
  onPullDownRefresh: function () {
    let self = this;
    self.data.page = 1;
    self.loadMore(true, false)
  },
  //上拉加载
  onReachBottom() {
    let that = this
    that.data.page++;
    //首先判断是加载更多分类数据还是无分类的数
    that.loadMore(false, true)
  },
  // 分享
  onShareAppMessage: function (res) {
    var that = this;
    return app.appShare();
  },
  onTabItemTap(item) {
    let self = this;
    self.data.page = 1;
    self.loadMore(true, false)
  },
  //触摸开始
  handletouchstart: function (event) {
    this.refreshView.handletouchstart(event)
  },
  //触摸移动
  handletouchmove: function (event) {
    this.refreshView.handletouchmove(event)
  },
  //触摸结束
  handletouchend: function (event) {
    this.refreshView.handletouchend(event)
  },
  //触摸取消
  handletouchcancel: function (event) {
    this.refreshView.handletouchcancel(event)
  },
  //页面滚动
  onPageScroll: function (event) {
    this.refreshView.onPageScroll(event)
  },
  myEventListener: function (e) {
    if (e.detail.loginSuccess) {
      this.onLoad()
    } else {
    }
  },
  //长按复制
  copyContent: function (e) {
    // this.setData({
    //   lock: true
    // })
  }
})
