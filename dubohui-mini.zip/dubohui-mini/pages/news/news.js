//index.js
//获取应用实例
const util = require("../../utils/api.js")
const app = getApp()
Page({
  data: {
    contentNotice:'',
    commentNotice:'c',
    commitResult:[]
  },
  onShow: function (option) {
    let self = this;
    self.pageDataList()
  },
  // 页面数据
  pageDataList:function(){
    let that = this;
    let params = {}
    util._request('/message/_messageCenterDabohui', params, 'post').then(res => {
      if (res.code == 0) {
        that.setData({
          commitResult: res.preload.results
        })
      }
    }).catch(e => {
    }) 
  },
  noticeClick:function(e){
    if (e.currentTarget.dataset.meaasgetype == 30){
      wx.navigateTo({
        url: '../noticeContent/noticeContent?messageType=' + e.currentTarget.dataset.meaasgetype,
      })
    } else if (e.currentTarget.dataset.meaasgetype == 40){
      wx.navigateTo({
        url: '../commentNotice/commentNotice?messageType=' + e.currentTarget.dataset.meaasgetype,
      })
    } else if (e.currentTarget.dataset.meaasgetype == 50){
      wx.navigateTo({
        url: '../isPraiseNotice/isPraiseNotice?messageType=' + e.currentTarget.dataset.meaasgetype,
      })
    }
  },
  // 下拉刷新
  onPullDownRefresh:function(){
    let self = this;
    wx.showNavigationBarLoading(); //在标题栏中显示加载
    self.pageDataList()
    wx.hideNavigationBarLoading() //完成停止加载
    wx.stopPullDownRefresh();
  },
  // 分享
  onShareAppMessage: function (res) {
    var that = this;
    return app.appShare();
  },
})
