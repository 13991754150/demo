//index.js
//获取应用实例
const util = require("../../utils/api.js");
const app = getApp()
const times = require("../../utils/times.js")
Page({
  data: {
    attention: '',
    inputShowed: false,
    nickname: '', //用户姓名
    createdat: '',
    avatar: '',
    content: '',
    location: '',
    commentnum: '',
    praisenum: '',
    pubid: '',
    isfollow: 0,
    ispraise: '',
    photos: [],
    userId: '',
    level: 0,
    extend:null,
    inputContent: '', //输入的内容
    commentFirstList: [], //评论列表
    toUserId: null, //用户id
    toCommentId: null, //评论 id,
    showBtn: false,
    placeholder: '说些什么...',
    imgHeight: 0,
    imgHeights: 0,
    bottom: 0,
    level: 0,
    ranking:0,
    adjust_position: false,
    cursor_spacing: 30,
    inputFoucus: false,
    pubItem: null, //发布的信息
    pageNum: 1,
    totalPage: 0,
    firstCommentID: null, //二级评论对应的一级评论的id
    count: 0,
    isIPX: app.globalData.isIPX, //判断是否是iphoneX
    shareNum: 0, //分享数
    shareReturn: 0,
    shareReturnStyle: 0,
    touchStartTime: 0, //触摸开始时间
    touchEndTime: 0, // 触摸结束时间
    isPlayState: false,
    videoSrc: '',
    videoContext: null,
    lock: false,
    shareNum:0
  },
  onLoad: function(option) {
    let that = this;
    //判断是不是iphoneX
    if (that.data.isIPX) {
      that.setData({
        bottom: 0
      })
    } else {
      that.setData({
        bottom: 0
      })
    }
    that.refreshView = this.selectComponent("#refreshView")
    if (option.pubId) {
      this.setData({
        pubid: option.pubId
      })
    }
    //加载评论数据
    if (that.data.pubid) {
      that.data.pageNum = 1;
      that.requestDetailMessage(false);
      that.commentFirst(true, false);
    }
    //判断返回首页按钮的显示隐藏
    if (option.shareReturn == 1) {
      that.setData({
        shareReturnStyle: 1
      })
    }
  },
  onShow: function() {
    //请求关注的状态
    this.requestAboutFocusMessage()
  },
  //请求详情接口
  requestDetailMessage(updata = true) {
    let that = this
    let params = {
      "pubId": that.data.pubid
    }
    util._request('/dabohui/content/publishDetail', params, 'post').then(res => {
      if (res.code == 0) {
        let item = res.preload.result
        that.setData({
          pubItem: item
        })
        //关注的时间
        let time = that.data.pubItem.createdAt;
        let timeStamp = times.timeStamps(time);
        let timeStamps = times.friendlyDate(timeStamp);
        //相册
        let photos = that.data.pubItem.pubDetail.extend.photos;
        if (updata) {
          that.setData({
            commentnum: Number(that.data.pubItem.pubDetail.commentNum)
          })
          that.dealLastPageCommentStatus()
        } else {
          that.setData({
            pubid: Number(that.data.pubItem.pubDetail.pubId),
            nickname: that.data.pubItem.userInfo.nickname,
            createdat: timeStamps,
            extend: that.data.pubItem.pubDetail.extend,
            avatar: that.data.pubItem.userInfo.avatar,
            ranking: that.data.pubItem.ranking,
            content: that.data.pubItem.pubDetail.content,
            location: that.data.pubItem.pubDetail.location,
            commentnum: Number(that.data.pubItem.pubDetail.commentNum),
            shareNum: Number(that.data.pubItem.pubDetail.shareNum),
            praisenum: Number(that.data.pubItem.pubDetail.praiseNum),
            isfollow: Number(that.data.pubItem.pubDetail.isFollow),
            ispraise: Number(that.data.pubItem.pubDetail.isPraise),
            photos: photos,
            userId: Number(that.data.pubItem.userInfo.userId),
            level: Number(that.data.pubItem.userInfo.level),
            shareNum: Number(that.data.pubItem.pubDetail.shareNum)
          })
          this.commentFirst(true, false);
          //加载分享数
          that.dealLastPageShareNum()
        }
      } else if (res.code == 1) {
        wx.showModal({
          title: '提示',
          content: res.message,
          showCancel: false,
          success: function(res) {
            if (res.confirm) {
              wx.navigateBack({
                delta: 1
              })
              var pages = getCurrentPages(); //获取页面栈
              if (pages.length > 1) {
                //上一个页面实例对象
                var prePage = pages[pages.length - 2];
                //调用上一个页面的onShow方法
                prePage.onPullDownRefresh()
              }
            }
          }
        })
      }
    }).catch(e => {
      console.log(e)
    })
  },
  //请求用户关注信息
  requestAboutFocusMessage() {
    if (!this.data.userId) {
      return;
    }
    let that = this
    //如果是用户自己的话
    if (app.globalData.userInfo.userId == that.data.userId) {
      that.setData({
        isfollow: -1,
        attention: ''
      })
      return;
    }
    let params = {
      "visitId": Number(that.data.userId)
    }
    util._request('/content/relation/visit', params, 'post').then(res => {
      // console.log(res)
      if (res.code == 0) {
        if (res.preload.result.followType >= 0) { //都是关注了的
          that.setData({
            isfollow: 1,
            attention: '已关注'
          })
          //刷新上一页
          that.dealLastPageFollowStatus()
        } else {
          that.setData({
            isfollow: 0,
            attention: '+关注'
          })
          //刷新上一页
          that.dealLastPageFollowStatus()
        }
      }
    })
  },
  //修改上一页的评论数
  dealLastPageCommentStatus() {
    let that = this;
    var pages = getCurrentPages(); //  获取页面栈
    // var currPage = pages[pages.length - 1];    // 当前页面
    var prevPage = pages[pages.length - 2]; // 上一个页面
    if (prevPage.route == "pages/personalHomePage/personalHomePage") { //刷新他人主页
      var allDynamicList = prevPage.data.dynamicList;
      for (var i = 0; i < allDynamicList.length; i++) {
        var pubItem = allDynamicList[i]
        if (pubItem.pubDetail.pubId == that.data.pubItem.pubId) {
          pubItem.pubDetail.commentNum = that.data.commentnum
        }
      }
      prevPage.setData({
        dynamicList: allDynamicList
      })
    } else if (prevPage.route == "pages/myPublish/myPublish") {
      var allLastThingList = prevPage.data.followResult;
      for (var i = 0; i < allLastThingList.length; i++) {
        var pubItem = allLastThingList[i]
        if (pubItem.pubDetail.pubId == that.data.pubItem.pubId) {
          pubItem.pubDetail.commentNum = that.data.commentnum
        }
      }
      prevPage.setData({
        followResult: allLastThingList
      })
    } else {
      var allLastThingList = prevPage.data.publishResult;
      for (var i = 0; i < allLastThingList.length; i++) {
        var pubItem = allLastThingList[i]
        if (pubItem.pubDetail.pubId == that.data.pubItem.pubId) {
          // console.log();
          pubItem.pubDetail.commentNum = that.data.commentnum;
        }
      }
      prevPage.setData({
        publishResult: allLastThingList
      })
    }

  },
  //修改上一页的点赞状态和数量
  dealLastPageSupportStatus() {
    let that = this;
    var pages = getCurrentPages(); //  获取页面栈
    var prevPage = pages[pages.length - 2]; // 上一个页面
    if (prevPage.route == "pages/personalHomePage/personalHomePage") { //刷新他人主页
      var allDynamicList = prevPage.data.dynamicList;
      for (var i = 0; i < allDynamicList.length; i++) {
        var pubItem = allDynamicList[i]
        if (pubItem.pubDetail.pubId == that.data.pubItem.pubId) {
          pubItem.pubDetail.isPraise = that.data.ispraise;
          pubItem.pubDetail.praiseNum = that.data.praisenum;
        }
      }
      prevPage.setData({
        dynamicList: allDynamicList
      })
    } else if (prevPage.route == "pages/myPublish/myPublish") {
      var allLastThingList = prevPage.data.followResult;
      for (var i = 0; i < allLastThingList.length; i++) {
        var pubItem = allLastThingList[i]
        if (pubItem.pubDetail.pubId == that.data.pubItem.pubId) {
          pubItem.pubDetail.isPraise = that.data.ispraise;
          pubItem.pubDetail.praiseNum = that.data.praisenum;
        }
      }
      prevPage.setData({
        followResult: allLastThingList
      })
    } else { //首页点击进入
      var allLastThingList = prevPage.data.publishResult;
      for (var i = 0; i < allLastThingList.length; i++) {
        var pubItem = allLastThingList[i]
        if (pubItem.pubDetail.pubId == that.data.pubItem.pubId) {
          pubItem.pubDetail.isPraise = that.data.ispraise;
          pubItem.pubDetail.praiseNum = that.data.praisenum;
        }
      }
      prevPage.setData({
        publishResult: allLastThingList
      })
    }
  },
  //刷新上一页所有的关注信息(直接获取上一页的数据进行刷新)
  dealLastPageFollowStatus() {
    let that = this;
    var pages = getCurrentPages(); //  获取页面栈
    var prevPage = pages[pages.length - 2]; // 上一个页面
    var allLastThingList = prevPage.data.publishResult;
    if (prevPage.route == "pages/index/index") {
      for (var i = 0; i < allLastThingList.length; i++) {
        var pubItem = allLastThingList[i]
        if (pubItem.userId == that.data.pubItem.userId) {
          //处理关注和未关注
          pubItem.pubDetail.isFollow = that.data.isfollow;
        }
      }
      prevPage.setData({
        publishResult: allLastThingList
      })
    }
  },
  // 修改上一页面分享数量
  dealLastPageShareNum: function() {
    let that = this;
    var pages = getCurrentPages(); //  获取页面栈
    var prevPage = pages[pages.length - 2]; // 上一个页面
    if (prevPage.route == 'pages/follow/follow') {
      let publishResult = prevPage.data.publishResult;
      for (var i = 0; i < publishResult.length; i++) {
        var pubItem = publishResult[i];
        if (pubItem.pubDetail.pubId == that.data.pubItem.pubId) {
          pubItem.pubDetail.shareNum = that.data.shareNum;
        }
      }
      prevPage.setData({
        publishResult: publishResult
      })
    } else if (prevPage.route == 'pages/myPublish/myPublish') {
      let followResult = prevPage.data.followResult;
      for (let j = 0; j < followResult.length; j++) {
        var pubItem = followResult[j];
        if (pubItem.pubDetail.pubId == that.data.pubItem.pubId) {
          pubItem.pubDetail.shareNum = that.data.shareNum;
        }
      }
      prevPage.setData({
        followResult: followResult
      })
    } else if (prevPage.route == 'pages/personalHomePage/personalHomePage') {
      let dynamicList = prevPage.data.dynamicList;
      for (let j = 0; j < dynamicList.length; j++) {
        var pubItem = dynamicList[j];
        if (pubItem.pubDetail.pubId == that.data.pubItem.pubId) {
          pubItem.pubDetail.shareNum = that.data.shareNum;
        }
      }
      prevPage.setData({
        dynamicList: dynamicList
      })
    }else{//首页分享
      let publishResult = prevPage.data.publishResult;
      for (var i = 0; i < publishResult.length; i++) {
        var pubItem = publishResult[i];
        if (pubItem.pubDetail.pubId == that.data.pubItem.pubId) {
          pubItem.pubDetail.shareNum = that.data.shareNum;
        }
      }
      prevPage.setData({
        publishResult: publishResult
      })
    }
  },
  // 点赞
  thumbs_up: function(e) {
    let self = this;
    if (self.data.ispraise == 0) {
      let params = {
        "inEntry": {
          "bizId": self.data.pubid,
          "bizType": 0,
          "praiseType": true
        }
      }
      util._request('/content/comment/praise', params, 'post').then(res => {
        if (res.code == 0) {
          self.setData({
            praisenum: self.data.praisenum += 1,
            ispraise: 1
          })
          self.dealLastPageSupportStatus()
        } else if (res.code == -1) {
          self.selectComponent("#login").showLogin()
        }
      }).catch(e => {})
    } else if (self.data.ispraise == 1) {
      let params = {
        "inEntry": {
          "bizId": self.data.pubid,
          "bizType": 0,
          "praiseType": false
        }
      }
      util._request('/content/comment/praise', params, 'post').then(res => {
        if (res.code == 0) {
          self.setData({
            praisenum: self.data.praisenum -= 1,
            ispraise: 0
          })
          self.dealLastPageSupportStatus()
        } else if (res.code == -1) {
          self.selectComponent("#login").showLogin()
        }
      }).catch(e => {})
    }
  },
  // 关注
  showLogins: function(e) {
    let self = this;
    if (self.data.isfollow == 0) {
      let params = {
        "followEntry": {
          "followId": self.data.userId,
          "followRemark": "",
          "followType": 0
        }
      }
      util._request('/content/relation/follow', params, 'post').then(res => {
        if (res.code == 0) {
          wx.showToast({
            title: '关注成功',
          })
          //加一个参数，用来表示，是否需要在关注页show的时候去请求数据
          app.needFollowRequestData = true;
          self.setData({
            attention: '已关注',
            isfollow: 1
          })
          self.dealLastPageFollowStatus()
        }
      }).catch(e => {})
    }
   
  },
  //点击顶部的评论图标
  comment_list: function() {
    this.setData({
      inputShowed: true,
      toUserId: null,
      toCommentId: null,
      placeholder: '说些什么...'
    })
  },
  // 获取一级评论
  commentFirst: function(pullDown = false, reachBottom = false) {
    let self = this;
    let params = {
      "pubId": Number(self.data.pubid),
      "page": {
        "pageSize": 20,
        "pageNum": self.data.pageNum,
        "sortBy": 1
      }
    }
    util._request('/dabohui/content/commentFirst', params, 'post').then(res => {
      if (res.code == 0) {
        self.data.totalPage = res.preload.totalPageNum;
        let commentList = res.preload.results;
        // 日期转时间戳
        for (let index in commentList) {
          let startAt = commentList[index].createdAt;
          let timeStamp = times.timeStamps(startAt);
          commentList[index].srartAtTimes = times.friendlyDate(timeStamp);
        }
        if (pullDown) { //如果是下拉刷新
          self.endThePullRequest()
          self.setData({
            commentFirstList: commentList
          })
        } else { //是上拉加载
          //将数组的前count删除
          for (var i = 0; i < self.data.count; i++) {
            self.data.commentFirstList.splice(0, 1);
          }
          self.data.count = 0;
          self.setData({
            commentFirstList: self.data.commentFirstList.concat(commentList)
          })

        }
      } else {
        if (pullDown) {
          self.endThePullRequest() //结束下拉刷新
        }
        self.dealTheCurrentPage()
      }
    }).catch(e => {
      if (pullDown) {
        self.endThePullRequest() //结束下拉刷新
      }
      self.dealTheCurrentPage()
    })
  },
  //请求出错的时候，要对page-1
  dealTheCurrentPage() {
    let that = this
    that.data.pageNum--;
    if (that.data.pageNum <= 0) {
      that.data.pageNum = 1;
    }
  },
  //结束下拉刷新相关操作
  endThePullRequest() {
    this.refreshView.stopPullRefresh();
  },
  otherIndex: function(e) {
    let self = this;
    if (e.currentTarget.dataset && e.currentTarget.dataset.userid) {
      if (e.currentTarget.dataset.userId == 0) {

      } else if (e.currentTarget.dataset.userid == app.globalData.userInfo.userId) {

      } else {
        wx.navigateTo({
          url: '../personalHomePage/personalHomePage?avatar=' + e.currentTarget.dataset.avatar + '&nickname=' + e.currentTarget.dataset.nickname + '&isFollow=' + e.currentTarget.dataset.isfollow + '&userId=' + e.currentTarget.dataset.userid,
        })
      }
    } else {
      if (e.currentTarget.dataset.item.userInfo.userId == 0) {

      } else if (e.currentTarget.dataset.item.userInfo.userId == app.globalData.userInfo.userId) {

      } else {
        wx.navigateTo({
          url: '../personalHomePage/personalHomePage?avatar=' + e.currentTarget.dataset.item.userInfo.avatar + '&nickname=' + e.currentTarget.dataset.item.userInfo.nickname + '&userId=' + e.currentTarget.dataset.item.userInfo.userId,
        })
      }
    }
  },
  // 二级评论（点击内容的时候回复）
  commentSecond: function(e) {
    //保存评论的id，因为二级评论的时候，我要把数据查进入
    let self = this;
    self.data.firstCommentID = e.currentTarget.dataset.tocommentid;
    self.setData({
      inputContent: '',
      inputShowed: true,
      toUserId: e.currentTarget.dataset.userid,
      toCommentId: e.currentTarget.dataset.tocommentid,
      placeholder: '回复' + e.currentTarget.dataset.nickname
    })

  },
  //点击名字的时候的回复
  commentSeconded: function(e) {
    let self = this;
    //保存评论的id，因为二级评论的时候，我要把数据查进入
    self.data.firstCommentID = e.currentTarget.dataset.tocommentid;
    self.setData({
      inputContent: '',
      inputShowed: true,
      toUserId: e.currentTarget.dataset.userid,
      toCommentId: e.currentTarget.dataset.tocommentid,
      placeholder: '回复' + e.currentTarget.dataset.nickname
    })
  },
  //删除自己评论
  delectComment: function(e) {
    let self = this;
    var findex = e.currentTarget.dataset.findex;
    var index = e.currentTarget.dataset.index;
    if (e.currentTarget.dataset.userid == app.globalData.userInfo.userId) {
      wx.showModal({
        title: '提示',
        content: '删除后不能恢复，是否确定要删除?',
        success(res) {
          if (res.confirm) {
            let params = {
              "inEntry": {
                "commentId": e.currentTarget.dataset.commid,
                "deleteType": true
              }
            }
            util._request('/content/comment/delete', params, 'post').then(res => {
              if (res.code == 0) {
                let commentList = self.data.commentFirstList;
                if (index == null || index == undefined) {
                  commentList.splice(findex, 1)
                } else {
                  let secondList = commentList[findex].secondList;
                  secondList.splice(index, 1)
                }
                self.setData({
                  commentFirstList: commentList
                })
                wx.showToast({
                  title: '删除成功',
                  icon: 'none'
                })
                self.requestDetailMessage(true);
              } else {
                wx.showToast({
                  title: res.message,
                  icon: 'none'
                })
              }
            }).catch((e) => {
              console.log(e)
            })
          }
        }
      })
      // }
    }
  },
  // 输入框输入文本的时候
  inputContnt: function(e) {
    this.setData({
      inputContent: e.detail.value,
      showBtn: e.detail.value
    })
  },
  // 提交评论
  submitComment: function() {
    let self = this;
    if (!app.token) {
      self.selectComponent("#login").showLogin()
      return;
    }
    let toId;
    let comId;
    if (self.data.toUserId == null) {
      toId = null;
      comId = null;
    } else {
      toId = Number(self.data.toUserId);
      comId = Number(self.data.toCommentId);
    }
    let params = {
      "commentEntry": {
        "bizId": Number(self.data.pubid),
        "bizType": 1,
        "toUserId": toId,
        "toCommentId": comId,
        "content": self.data.inputContent,
        "extend": {}
      }
    }
    util._request('/dabohui/content/comment', params, 'post').then(res => {
      if (res.code == 0) {
        //如果是一级评论，插入数组滑到最上边
        if (!self.data.toUserId) { //是一级评论
          self.data.count++;
          let startAt = res.preload.result.createdAt;
          let timeStamp = times.timeStamps(startAt);
          res.preload.result.srartAtTimes = times.friendlyDate(timeStamp);
          self.data.commentFirstList.unshift(res.preload.result);
          self.setData({
            commentFirstList: self.data.commentFirstList
          })
          wx.pageScrollTo({
            scrollTop: 0,
          })
        } else { //如果是二级评论，直接插入self.data.firstCommentID
          let commentID = self.data.firstCommentID;
          if (commentID) {
            self.data.firstCommentID = null;
            for (var i = 0; i < self.data.commentFirstList.length; i++) {
              let item = self.data.commentFirstList[i]
              if (item.commentId == commentID) {
                if (item.secondList != undefined) { //插入数据
                  item.secondList.push(res.preload.result)
                } else {
                  let arr = []
                  arr.push(res.preload.result)
                  item.secondList = arr
                }
                break;
              }
            }
            self.setData({
              commentFirstList: self.data.commentFirstList
            })
          }
        }
        //直接将评论数加一
        self.data.commentnum = self.data.commentnum + 1;
        self.setData({
          commentnum: self.data.commentnum
        })
        self.dealLastPageCommentStatus()
        //处理上一页的评论数
        self.setData({
          inputContent: '',
          toUserId: null,
          toCommentId: null
        })
      } else {
        wx.showToast({
          title: res.message,
          icon: "none"
        })
      }
    }).catch(e => {
      console.log(e)
    })
  },
  previewImg: function(e) {
    var index = e.currentTarget.dataset.index;
    let item = this.data.photos;
    var arr = []
    for (let index in item) {
      let imgUrlList = item[index].url;
      imgUrlList = imgUrlList.replace('!list','!detail')
      arr.push(imgUrlList)
    }
    wx.previewImage({
      current: item[index].url.replace('!list', '!detail'), //当前图片地址
      urls: arr, //所有要预览的图片的地址集合 数组形式
      success: function(res) {},
      fail: function(res) {},
      complete: function(res) {},
    })
  },
  // 分享
  onShareAppMessage: function(res) {
    var that = this;
    if (res.from === 'button') {
      that.data.shareReturn = true;
      let params = {
        "bizIds": [that.data.pubid]
      }
      util._request('/content/publish/updateShare', params, 'post').then(res => {
        if (res.code == 0) {
          that.data.shareNum += 1
          console.log(that.data.shareNum)
          that.setData({
            shareNum: that.data.shareNum
          })
          that.dealLastPageShareNum()
        } else if (res.code == -1) {}
      }).catch(e => { //请求失败
      })
      return {
        title: "大播汇",
        path: "/pages/dynamic/dynamic?pubId=" + that.data.pubid + '&shareReturn=' + 1,
        success: function (a) { },
        fail: function (e) { }
      };
    } else if (res.from === 'menu') {
      return app.appShare();
    }
  },
  //获取焦点
  foucus: function(e) {
    var that = this;
    that.setData({
      bottom: e.detail.height,
      inputShowed: true,
      showBtn: that.data.inputContent
    })
  },
  blur: function(e) {
    var that = this;
    if (that.data.isIPX) {
      that.setData({
        bottom: 0
      })
    } else {
      that.setData({
        bottom: 0
      })
    }
    that.setData({
      inputShowed: false,
      placeholder: '说些什么...',
      showBtn: that.data.inputContent
    })
  },
  onPullDownRefresh() { //下拉加载
    //请求最新的评论数据
    this.data.count = 0;
    this.data.pageNum = 1;
    this.commentFirst(true, false);
  },
  onReachBottom() {
    //上拉加载更多
    this.data.pageNum++;
    if (this.data.pageNum <= this.data.totalPage) {
      this.commentFirst(false, true);
    }
  },
  //触摸开始
  handletouchstart: function(event) {
    this.refreshView.handletouchstart(event)
    this.setData({
      touchStartTime: event.timeStamp
    })
  },
  //触摸移动
  handletouchmove: function(event) {
    this.refreshView.handletouchmove(event)
  },
  //触摸结束
  handletouchend: function(event) {
    this.refreshView.handletouchend(event)
    this.setData({
      touchEndTime: event.timeStamp
    })
  },
  //触摸取消
  handletouchcancel: function(event) {
    this.refreshView.handletouchcancel(event)
  },
  //页面滚动
  onPageScroll: function(event) {
    this.refreshView.onPageScroll(event)
  },
  //返回首页
  returnIndexPage: function() {
    wx.reLaunch({
      url: '/pages/index/index'
    })
  },
  videoPlay: function (e) {
    let videoSrc = e.currentTarget.dataset.src;
    //跳转到全屏播放页面
    wx.navigateTo({
      url: '/pages/videoFull/videoFull?src=' + videoSrc,
    })
  },
  //长按复制
  copyContent: function (e) {
    // this.setData({
    //   lock: true
    // })
  }
})