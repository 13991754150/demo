
//index.js
//获取应用实例
const util = require("../../utils/api.js")
const app = getApp()
const times = require("../../utils/times.js")
Page({
  data: {
    inputShowed: false,
    avatar:'',
    nickname:'',
    ranking:0,
    createdat:'',
    content:'',
    num:0,
    pubId:0,
    commitList:[],
    inputContnts:'',
    nowUserId: 0,
    showBtn: false,
    level:0,
    page: 1,
    page_size: 20,
    scrollTop: 0,
    scrollHeight: 0,
    bottom: 0,
    adjust_position:false,
    pubItem: null,//发布的信息
    result:'',
    userId:'',
    isIPX: app.globalData.isIPX,//判断是否是iphoneX
    touchStartTime: 0, //触摸开始时间
    touchEndTime: 0, // 触摸结束时间
    lock:false
  },
  onLoad: function (option) {
    let that = this;
    this.refreshView = this.selectComponent("#refreshView")
    if (option.pubItem){
      // let item = (JSON.parse(option.pubItem)).datalist;
      // that.setData({
      //   pubItem: item
      // })
      // let time = that.data.pubItem.startAt;
      // let timeStamp = times.timeStamps(time);
      // let timeStamps = times.friendlyDate(timeStamp);
     
    }
    if (option.pubId) {
      that.setData({
        pubId: option.pubId
      })
    }
    if (that.data.pubId) {
      that.commentFirst(true, false)
    }
    //判断是不是iphoneX
    if (that.data.isIPX) {
      that.setData({
        bottom: 0
      })
    } else {
      that.setData({
        bottom: 0
      })
    }
  },
  onShow:function(){
    if (this.data.pubId) {
      this.detailFun();
    }
    this.setData({
      nowUserId: app.globalData.userInfo.userId,
    })
  },
  detailFun:function(){
    let self = this;
    let params={
      "pubId": self.data.pubId
    }
    util._request('/dabohui/content/publishDetail', params, 'post').then(res => {
      if(res.code == 0){
        let result = res.preload.result;
        let time = result.startAt;
        let timeStamp = times.timeStamps(time);
        let timeStamps = times.friendlyDate(timeStamp);
        let num = result.pubDetail.joinNum;
        let ranking = result.ranking
        self.setData({
          result: result,
          createdat: timeStamps,
          num: result.pubDetail.joinNum,
          avatar: result.userInfo.avatar,
          nickname: result.userInfo.nickname,
          createdat: result.startAt,
          content: result.pubDetail.content,
          ranking: result.ranking
        })
        self.dealLastPageNums()
      } else if (res.code == 1) {
        wx.showModal({
          title: '提示',
          content: res.message,
          showCancel: false,
          success:function(res){
            if(res.confirm){
              wx.navigateBack({
                delta:1
              })
              var pages = getCurrentPages();//获取页面栈
              if (pages.length > 1) {
                //上一个页面实例对象
                var prePage = pages[pages.length - 2];
                //调用上一个页面的onShow方法
                prePage.onPullDownRefresh()
              }
            }
          }
        })
      }    
    }).catch(e => {
    })
  },
  // 传参
  dealLastPageNums() {
    let that = this;
    var pages = getCurrentPages();             //  获取页面栈
    var prevPage = pages[pages.length - 2];    // 上一个页面
    var allLastThingList = prevPage.data.problemResult;
    if (prevPage.route == "pages/myPublish/myPublish") {
      for (var i = 0; i < allLastThingList.length; i++) {
        var pubItem = allLastThingList[i]
        if (pubItem.pubDetail.pubId == that.data.pubId) {
          //处理关注和未关注
          pubItem.pubDetail.joinNum = that.data.num;
        }
      }
      prevPage.setData({
        problemResult: allLastThingList
      })
    } else if (prevPage.route == "pages/ansower/ansower" || prevPage.route == "pages/personalHomePage/personalHomePage"){
      for (var i = 0; i < allLastThingList.length; i++) {
        var pubItem = allLastThingList[i]
        if (pubItem.pubDetail.pubId == that.data.pubId) {
          //处理关注和未关注
          pubItem.pubDetail.joinNum = that.data.num;
        }
      }
      prevPage.setData({
        problemResult: allLastThingList
      })
    } 
  },
  // 一级评论
  commentFirst: function (pullDown = false, reachBottom = false){
    let self = this;
    let params={
      "pubId": Number(this.data.pubId),
      "page": {
        "pageSize": 20,
        "pageNum": self.data.page,
        "sortBy": 1
      }
    }
    util._request('/dabohui/content/commentFirst', params, 'post').then(res => {
      if (res.code == 0) {
        if(pullDown){
          self.endThePullRequest()//结束下拉刷新
          self.setData({
            commitList: res.preload.results
          })
        }else{
          self.setData({
            commitList: self.data.commitList.concat(res.preload.results)
          })
        }
        self.dealLastPageCommentStatus()
      }else if(res.code == -1){
        self.dealTheCurrentPage()
        app.reInitData()
        if (pullDown) {
          self.endThePullRequest()//结束下拉刷新
        }
      }else{
        self.dealTheCurrentPage()
        if (pullDown) {
          self.endThePullRequest()//结束下拉刷新
        } 
      }
    }).catch(e => {
      if (pullDown) {
        self.endThePullRequest()//结束下拉刷新
      }
      self.dealTheCurrentPage()

    })
  },
  //结束下拉刷新相关操作
  endThePullRequest() {
    this.refreshView.stopPullRefresh();
  },
  dealTheCurrentPage() {
    let that = this
    that.data.page--;
    if (that.data.page <= 0) {
      that.data.page = 1;
    }
  },
  onPullDownRefresh:function(){
    let self = this;
    self.data.page = 1;
    self.commentFirst(true, false)
  },  
  dealLastPageCommentStatus() {
    let that = this;
    var pages = getCurrentPages();             //  获取页面栈
    var prevPage = pages[pages.length - 2];    // 上一个页面
    var allLastThingList = prevPage.data.problemResult;
    for (var i = 0; i < allLastThingList.length; i++) {
      var pubItem = allLastThingList[i];
      if (pubItem.pubDetail.pubId == that.data.pubId) {
        pubItem.pubDetail.joinNum = that.data.num
        break;
      }
    }
    prevPage.setData({
      problemResult: allLastThingList
    })
  },
  // 输入框
  inputContnt:function(e){
      this.setData({
        inputContnts: e.detail.value,
        showBtn: e.detail.value
      })
  },
  //发送评论
  commentBtn:function(){
    let self = this;
    if(!self.data.inputContnts){
      wx.showToast({
        title: '评论内容不能为空',
        icon:'none'
      })
      return
    }
    let params = {
      "commentEntry": {
        "bizId": Number(this.data.pubId),
        "bizType": 1,
        "content": self.data.inputContnts,
        "extend": {}
      }
    }
    util._request('/dabohui/content/comment', params, 'post').then(res => {
      if (res.code == 0) {
        wx.showToast({
          title: '回答成功',
          duration:2000
        })
        self.setData({
          inputContnts: '',
          showBtn: false,
        })
        //直接将后台返回的数据插入到第一条，然后scroll到最上面
        let dataContent = res.preload.result;
        self.data.commitList.unshift(dataContent);
        self.setData({
          commitList: self.data.commitList
        })
        wx.pageScrollTo({
          scrollTop: 0,
        })
        self.detailFun()
      }else{
        wx.showToast({
          title: res.message,
          icon: "none"
        })
      }
    }).catch(e => {
      console.log(e)
    })
  },
  // 分享
  onShareAppMessage: function (res) {
    var that = this;
    return app.appShare();
  },
  otherIndex: function (e) {
    let self = this;
    if (self.data.userId == 0) {

    } else if (self.data.userId == app.globalData.userInfo.userId) {
    
    } else {
      wx.navigateTo({
        url: '../personalHomePage/personalHomePage?avatar=' + e.currentTarget.dataset.avatar + '&nickname=' + e.currentTarget.dataset.nickname + '&isFollow=' + e.currentTarget.dataset.isfollow + '&userId=' + e.currentTarget.dataset.userid,
      })
    }
  },
  foucus: function (e) {
    var that = this;
    that.setData({
      bottom: e.detail.height,
      inputShowed: true,
      showBtn: that.data.inputContnts
    })
  },
  blur: function (e) {
    var that = this;
    if (that.data.isIPX) {
      that.setData({
        bottom: 0
      })
    } else {
      that.setData({
        bottom: 0
      })
    }
    that.setData({
      // bottom: 0,
      inputShowed: false,
      showBtn: that.data.inputContnts
    })
  },
  //触摸开始
  handletouchstart: function (event) {
    this.refreshView.handletouchstart(event)
    this.setData({
      touchStartTime: event.timeStamp
    })
  },
  //触摸移动
  handletouchmove: function (event) {
    this.refreshView.handletouchmove(event)
  },
  //触摸结束
  handletouchend: function (event) {
    this.refreshView.handletouchend(event)
    this.setData({
      touchEndTime: event.timeStamp
    })
  },
  //触摸取消
  handletouchcancel: function (event) {
    this.refreshView.handletouchcancel(event)
  },
  //页面滚动
  onPageScroll: function (event) {
    this.refreshView.onPageScroll(event)
  },
  delectComment(e){
    console.log(e)
    let index = e.currentTarget.dataset.index;
    let commentid = e.currentTarget.dataset.commentid;
    let userid = e.currentTarget.dataset.userid;
    let self = this;
    if (userid == app.globalData.userInfo.userId) {
      wx.showModal({
        title: '提示',
        content: '删除后不能恢复，是否确定要删除?',
        success(res) {
          if (res.confirm) {
            let params = {
              "inEntry": {
                "commentId": commentid,
                "deleteType": true
              }   
            }
            util._request('/content/comment/delete', params, 'post').then(res => {
              if (res.code == 0) {
                let commentLists = self.data.commitList;
                commentLists.splice(index, 1)
                self.setData({
                  commitList: commentLists
                })
                self.detailFun()
                wx.showToast({
                  title: '删除成功',
                  icon: 'none'
                })
              } else {
                wx.showToast({
                  title: res.message,
                  icon: 'none'
                })
              }
            }).catch((e) => {
              console.log(e)
            })
          }
        }
      })
    }
  },
  //长按复制
  copyContent: function (e) {
    // this.setData({
    //   lock: true
    // })
  }
})
