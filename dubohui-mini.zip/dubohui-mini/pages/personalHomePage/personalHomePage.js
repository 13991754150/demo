//index.js
//获取应用实例
const util = require("../../utils/api.js");
const app = getApp()
const times = require("../../utils/times.js")

Page({
  data: {
    navbar: ['动态', '解惑'],
    currentTab: 0,
    avatar: '',
    followNum: 0,
    fansNum: 0,
    userId: '',
    level:0,
    isFollow: -1,//是否关注了
    dynamicList: [],
    problemResult: [],
    nickname:'',
    title:'',
    pageNum: 1,
    totalPage: 1,
    pubIdArr: [],
    shareReturn: 0,
    result:0,//加v认证
    examineName:'',
    examineType:'',
    examinePosition:'',
    examineFlowerName:'',
    examineDesc:'',
    examineStatus: 0,
    isPlayState:false,
    videoSrc: '',
    videoContext: null,
    lock: false
  },
  onShow() {
    //是否关注
    this.requestAboutFocusMessage()
    //请求关注和粉丝数据
    this.requestFollowAndFansCount()
    // this.apply()
  },
//请求用户关注信息
  requestAboutFocusMessage() {
    let params = {
      "visitId": Number(this.data.userId)
    }
    util._request('/content/relation/visit', params, 'post').then(res => {
      if (res.code == 0) {
        if (res.preload.result.followType >= 0) {//都是关注了的
          this.setData({
            isFollow: 1
          })
        } else {
          this.setData({
            isFollow: 0
          })
        }
      }
    })
  },
  onLoad: function (option) {
    this.refreshView = this.selectComponent("#refreshView")
    let self = this;
    self.setData({
      avatar: option.avatar,
      userId: option.userId,
      nickname:option.nickname,
      level:Number(option.level),
      title: option.nickname+'的主页'
    })
    //请求动态
    self.dynamicFun(true, false);
    self.otherMessage()
    this.shareBtn()
  },
  //他人入驻信息
  otherMessage:function(){
    let self = this;
    let params = {
      "visitId": Number(self.data.userId)
    }
    util._request('/dabohui/member/visitEnter',params,'post').then(res =>{
      let result = res.preload.result;
      let examineTypename;
      if (result.examineType == 0){
        examineTypename = '机构'
      } else if (result.examineType == 1){
        examineTypename = '主播'
      }
      else if (result.examineType == 2) {
        examineTypename = '商家'
      }
      else if (result.examineType == 3) {
        examineTypename = '基地'
      }
      else if (result.examineType == 4) {
        examineTypename = '服务'
      }else{
        examineTypename = ''
      }
      self.setData({
        examineName: result.examineName,
        examineType: examineTypename,
        examinePosition: result.examinePosition,
        examineFlowerName: result.examineFlowerName,
        examineDesc: result.examineDesc,
        examineStatus: result.examineStatus
      })
    }).catch(e => {
    })
  },
//请求关注和粉丝数据
  requestFollowAndFansCount() {
    let that = this
    let params = {
      "visitId": Number(that.data.userId)
    }
    util._request('/content/relation/numVisit', params, 'post').then(res => {
      if (res.code == 0) {
        that.setData({
          followNum: res.preload.result.followNum,
          fansNum: res.preload.result.fansNum
        })
      }
    }).catch(e => {
    })
  },
  // 动态，问题
  dynamicFun: function (pullDown = false, reachBottom = false) {
    let self = this;
    let params = {
      "inEntry": {
        "pubType": 0,
        "visitId": Number(self.data.userId),
      },
      "page": {
        "pageSize": 20,
        "pageNum": self.data.pageNum,
        "sortBy": 1
      }
    }
    util._request('/dabohui/content/publishUser', params, 'post').then(res => {
      if (res.code == 0) {
        self.data.totalPage = res.preload.totalPageNum
        let dynamicList = res.preload.results;
        let pubArr = [];
        // 日期转时间戳
        for (let index in dynamicList) {
          let startAt = dynamicList[index].startAt;
          let timeStamp = times.timeStamps(startAt);
          dynamicList[index].srartAtTimes = times.friendlyDate(timeStamp);
          let avatar = dynamicList[index].userInfo.avatar;
          if (avatar == '') {
            dynamicList[index].userInfo.avatar = "../../image/head.png"
          }
          let pubId = dynamicList[index].pubDetail.pubId;
          pubArr.push(pubId)
        }

        if (pullDown) {//下拉
          self.endThePullRequest()
          self.setData({
            dynamicList: dynamicList,
            pubIdArr: pubArr
          })
        } else {//上拉
          self.setData({
            dynamicList: self.data.dynamicList.concat(dynamicList),
            pubIdArr: pubArr
          })
        }  
      } else {
        if (pullDown) {
          self.endThePullRequest()
        }
        self.dealTheCurrentPage()
      }

    }).catch(e => {
      if (pullDown) {
        self.endThePullRequest()
      }
      self.dealTheCurrentPage()
    })
  },
  //结束下拉刷新相关操作
  endThePullRequest() {
    this.refreshView.stopPullRefresh();
  },
  //请求出错的时候，要对page-1
  dealTheCurrentPage() {
    let that = this
    that.data.pageNum--;
    if (that.data.pageNum <= 0) {
      that.data.pageNum = 1;
    }
  },
  //请求问题
  problemFun: function (pullDown = false, reachBottom = false) {
    let self = this;
    let paramsList = {
      "inEntry": {
        "pubType": 1,
        "visitId": Number(self.data.userId),
      },
      "page": {
        "pageSize": 20,
        "pageNum": self.data.pageNum,
        "sortBy": 1
      }
    }
    util._request('/dabohui/content/publishUser', paramsList, 'post').then(res => {
      if (res.code == 0) {
        self.data.totalPage = res.preload.totalPageNum
        let problemResult = res.preload.results;
        // 日期转时间戳
        for (let index in problemResult) {
          let startAt = problemResult[index].startAt;
          let timeStamp = times.timeStamps(startAt);
          problemResult[index].srartAtTimes = times.friendlyDate(timeStamp);

          let avatar = problemResult[index].userInfo.avatar;
          if (avatar == '') {
            problemResult[index].userInfo.avatar = "../../image/head.png"
          }
        }

        if (pullDown) {//下拉
          self.endThePullRequest()
          self.setData({
            problemResult: problemResult
          })
        } else {//上拉
          self.setData({
            problemResult: self.data.problemResult.concat(problemResult)
          })
        }
      } else {
        if (pullDown) {
          self.endThePullRequest()
        }
        self.dealTheCurrentPage()
      }
    }).catch(e => {
      if (pullDown) {
        self.endThePullRequest()
      }
      self.dealTheCurrentPage()
    })
  },
  //点击选择动态和问题
  navbarTap: function (e) {
    let that = this
    if (e.currentTarget.dataset.idx == that.data.currentTab) {
      return;
    }
    that.setData({
      currentTab: e.currentTarget.dataset.idx
    })
    that.data.pageNum = 1
    switch (that.data.currentTab) {
      case 0:
      //动态
        that.dynamicFun(true, false)
      break;
      default:
        that.problemFun(true, false)
      break;
    }
  },
  // 关注按钮
  showFollow: function () {
    let self = this;
    let isFollow = self.data.isFollow;
    // isFollow为0是已关注，取消关注
    if (isFollow == 1) {
      wx.showModal({
        title: '提示',
        content: '您是否要取消关注该用户',
        success: function (res) {
          if (res.confirm) {
            let params = {
              "followId": self.data.userId,
            }
            util._request('/content/relation/unFollow', params, 'post').then(res => {
              if (res.code == 0) {
                self.setData({
                  isFollow: 0
                })
                //关注页需要刷新
                app.needFollowRequestData = true;
                //请求一下关注和粉丝接口，刷新数据
                self.requestFollowAndFansCount();
                self.isfollowChangeData()
              }
            }).catch(e => {
            })
          }
        }
      })
    } else {
      let params = {
        "followEntry": {
          "followId": self.data.userId,
          "followRemark": "",
          "followType": 0
        }
      }
      util._request('/content/relation/follow', params, 'post').then(res => {
        if (res.code == 0) {
          self.setData({
            isFollow: 1
          })
          //关注页需要刷新
          app.needFollowRequestData = true;
          //请求一下关注和粉丝接口，刷新数据
          self.requestFollowAndFansCount();
          self.isfollowChangeData()
        }
      }).catch(e => {
      })
    }
  },
  //点赞
  thumbs_up: function (e) {
    let self = this;
    let index = e.currentTarget.dataset.index;
    let dynamicList = self.data.dynamicList;
    for (let i in dynamicList) {
      if (i == index) {
        if (dynamicList[i].pubDetail.isPraise == 0) {
          let params = {
            "inEntry": {
              "bizId": e.currentTarget.dataset.pubid,
              "bizType": 0,
              "praiseType": true
            }
          }
          util._request('/content/comment/praise', params, 'post').then(res => {
            if (res.code == 0) {
              dynamicList[i].pubDetail.praiseNum += 1;
              dynamicList[i].pubDetail.isPraise = 1;
              self.setData({
                dynamicList: dynamicList
              })
            } else {
              wx.showModal({
                title: '提示',
                content: res.message,
              })
            }
          }).catch(e => {
          })
        } else {
          let params = {
            "inEntry": {
              "bizId": e.currentTarget.dataset.pubid,
              "bizType": 0,
              "praiseType": false
            }
          }
          util._request('/content/comment/praise', params, 'post').then(res => {
            if (res.code == 0) {
              if (dynamicList[i].pubDetail.praiseNum == 0) {
                dynamicList[i].pubDetail.praiseNum = 0
              } else {
                dynamicList[i].pubDetail.praiseNum -= 1;
              }
              dynamicList[i].pubDetail.isPraise = 0;
              self.setData({
                dynamicList: dynamicList
              })
            } else {
              wx.showModal({
                title: '提示',
                content: res.message,
              })
            }
          }).catch(e => {
          })
        }
      }
    }
  },
  //查看动态
  dynamicClick: function (e) {
    if (this.data.lock) {
      return;
    }
    let pubId = e.currentTarget.dataset.item.pubId;
    // let itemString = JSON.stringify(item);
    wx.navigateTo({
      url: '../dynamic/dynamic?pubId=' + pubId,
    })
  },
  previewImg: function (e) {
    let self = this;
    let pubIndex = e.currentTarget.dataset.pubindex;
    var index = e.currentTarget.dataset.index;
    let imageUrls = self.data.dynamicList[pubIndex].pubDetail.extend.photos;
    var arr = []
    for (let index in imageUrls) {
      let imgUrllist = imageUrls[index].url;
      imgUrllist = imgUrllist.replace('!list', '!detail')
      arr.push(imgUrllist)
    }
    wx.previewImage({
      current: imageUrls[index].url.replace('!list', '!detail'),     //当前图片地址
      urls: arr,               //所有要预览的图片的地址集合 数组形式
      success: function (res) { },
      fail: function (res) { },
      complete: function (res) { },
    })
  },
  clickToQuestion: function (e) {
    if (this.data.lock) {
      return;
    }
    let pubId = e.currentTarget.dataset.item.pubId;
    // let itemString = JSON.stringify(item);
    wx.navigateTo({
      url: '../problemDetail/problemDetail?pubId=' + pubId,
    })
  },
  // 分享
  onShareAppMessage: function (res) {
    var that = this;
    let pubid = res.target.dataset.pubid;
    if (res.from === 'button') {
      let params = {
        "bizIds": [pubid]
      }
      util._request('/content/publish/updateShare', params, 'post').then(res => {
        console.log(res)
        if (res.code == 0) {
          let dynamicList = that.data.dynamicList;
          for (let index in dynamicList) {
            if (dynamicList[index].pubId == pubid) {
              dynamicList[index].pubDetail.shareNum += 1;
              break;
            }
          }
          that.setData({
            dynamicList: dynamicList
          })
        } else if (res.code == -1) {
        }
      }).catch(e => {//请求失败
      })
      return {
        title: "大播汇",
        path: "/pages/dynamic/dynamic?pubId=" + res.target.dataset.pubid + '&shareReturn=' + 1,
        success: function (a) {
          console.log(a)
        },
        fail: function (e) {
        }
      };
      
    } else if (res.from === 'menu') {
      return app.appShare();
    }
  },
  // 下拉刷新
  onPullDownRefresh: function () {
    let that = this
    that.data.pageNum = 1;
    switch (that.data.currentTab) {
      case 0:
        //动态
        that.dynamicFun(true, false)
        break;
      default:
        that.problemFun(true, false)
        break;
    }
  },
  //上拉加载
  onReachBottom() {
    let that = this
    that.data.pageNum++;
    if (that.data.pageNum > that.data.totalPageNum) {
      return;
    }
    switch (that.data.currentTab) {
      case 0:
        //动态
        that.dynamicFun(false, true)
        break;
      default:
        that.problemFun(false, true)
        break;
    }
  },
  // 点击关注按钮箱上一页面传值
  isfollowChangeData:function(){
    let that = this;
    var pages = getCurrentPages();
    var prevPage = pages[pages.length - 2];    // 上一个页面
    if (prevPage.route == "pages/index/index") {
      var allLastThingList = prevPage.data.publishResult;
      for (var i = 0; i < allLastThingList.length; i++){
        var isFollowChange = allLastThingList[i]
        if (isFollowChange.userInfo.userId == that.data.userId){
          isFollowChange.pubDetail.isFollow = that.data.isFollow;
        }
      }
      prevPage.setData({
        publishResult: allLastThingList
      })
    } else if (prevPage.route == "pages/follow/follow") {
      var allLastThingList = prevPage.data.publishResult;
      for (var i = 0; i < allLastThingList.length; i++) {
        var isFollowChange = allLastThingList[i]
        if (isFollowChange.userInfo.userId == that.data.userId) {
          isFollowChange.pubDetail.isFollow = that.data.isFollow;
        }
      }
      prevPage.setData({
        publishResult: allLastThingList
      })
    } else if (prevPage.route == "pages/followList/followList"){
      var allLastThingList = prevPage.data.result;
      for (var i = 0; i < allLastThingList.length; i++) {
        var isFollowChange = allLastThingList[i]
        if (isFollowChange.userId == that.data.userId && !that.data.isFollow) {
          allLastThingList.splice(i, 1);
          break;
        }
      }
      prevPage.setData({
        result: allLastThingList
      })
    } else if (prevPage.route == "pages/fansList/fansList"){
      var allLastThingList = prevPage.data.result;
      for (var i = 0; i < allLastThingList.length; i++) {
        var isFollowChange = allLastThingList[i]
        if (isFollowChange.userId == that.data.userId) {
          isFollowChange.isFriend = that.data.isFollow;
        }
      }
      prevPage.setData({
        result: allLastThingList
      })
    }
  },
  //分享数增加
  changeLastpageShareNum:function(){
    let that = this;
    var pages = getCurrentPages();
    var prevPage = pages[pages.length - 2];    // 上一个页面
   
  },

  //触摸开始
  handletouchstart: function (event) {
    this.refreshView.handletouchstart(event)
  },
  //触摸移动
  handletouchmove: function (event) {
    this.refreshView.handletouchmove(event)
  },
  //触摸结束
  handletouchend: function (event) {
    this.refreshView.handletouchend(event)
  },
  //触摸取消
  handletouchcancel: function (event) {
    this.refreshView.handletouchcancel(event)
  },
  //页面滚动
  onPageScroll: function (event) {
    this.refreshView.onPageScroll(event)
  },
  shareBtn: function () {
    let self = this;
  },
  videoPlay: function (e) {
    let videoSrc = e.currentTarget.dataset.src;
    //跳转到全屏播放页面
    wx.navigateTo({
      url: '/pages/videoFull/videoFull?src=' + videoSrc,
    })
  },
  //长按复制
  copyContent: function (e) {
    // this.setData({
    //   lock: true
    // })
  }
})
