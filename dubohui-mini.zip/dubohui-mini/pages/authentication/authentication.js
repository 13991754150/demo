// pages/authentication/authentication.js
const util = require("../../utils/api.js");
const app = getApp();
Page({
  data: {
   items:[
     { name: '机构', value: '机构',id:0,checked: false},
     { name: '主播', value: '主播', id: 1, checked: false},
     { name: '商家', value: '商家', id: 2, checked: false},
     { name: '基地', value: '基地', id: 3, checked: false},
     { name: '服务商', value: '服务商', id: 4, checked: false}
   ],
    classifys:true,
    classifyNames:'',
    nameContent:'',//名称
    workContent:'',//职位
    poneContent:'',//电话
    wechatContent:'',//微信
    nicknameContent:'',//花名
    descContent:'',//描述
    integer:0,
    isShowText: false,
    onFocus: false,
    showBtn:true,
    disabledData:false,
    options:0
  },
  showSelext:function(){
    let self = this;
    if (self.data.options == 2 || self.data.options == 1){
      self.setData({
        classifys: true,
      })
    }else{
      self.setData({
        classifys: false,
        isShowText: true,
        onFacus: false,
      })
    }
    
  },
  onShowTextare: function () {
    this.setData({
      isShowText: false,
      onFacus: true
    })
  },
  onShowText: function () {
    this.setData({
      isShowText: true,
      onFacus: false
    })
  },
  onLoad:function(option){
    let self = this;
    if (option.result == 2 || option.result == 1){
      self.getInputData()
    }
    self.setData({
      options: option.result
    })
    //获取导航栏高度
    
  },
  // 单选
  radioChange: function (e) {
    let self = this;
    self.setData({
      classifyName: e.detail.value
    })
  },
  radioValue:function(e){
    console.log(e)
    let self = this;
    self.setData({
      integer: e.currentTarget.dataset.id
    })
  },
  //获取页面输入的数据
  getInputData(){
    let self = this;
    let params ={}
    util._request('/dabohui/member/getEnter', params, 'post').then(res =>{
      if(res.code == 0){
        let result = res.preload.result;
        let nicknameContent = result.examineFlowerName;
        let descContent = result.examineDesc;
        let classifyNames = result.examineType;
        if (classifyNames == 0){
          classifyNames = '机构'
        } else if (classifyNames == 1){
          classifyNames = '主播'
        } else if (classifyNames == 2) {
          classifyNames = '商家'
        } else if (classifyNames == 3) {
          classifyNames = '基地'
        } else if (classifyNames == 4) {
          classifyNames = '服务商'
        }
        if (nicknameContent == "" ){
          self.setData({
            nicknameContent: '暂无',
          })
        }else{
          self.setData({
            nicknameContent: nicknameContent,
          })
        }
        if (descContent == ''){
          self.setData({
            descContent: '暂无',
          })
        }else{
          self.setData({
            descContent: descContent,
          })
        }
        self.setData({
          disabledData: true,
          classifys: true,
          nameContent: result.examineName,
          workContent: result.examinePosition, 
          poneContent: result.examineMobile,
          wechatContent: result.examineWeChat,          
          showBtn:false,
          classifyNames: classifyNames
        })
      }
    }).catch((e)=>{

    })
  },
  // 单选确定
  classifyBtn: function () {
    let self = this;
    self.setData({
      classifys: true,
      checked:!self.data.checked,
      isShowText: false,
      onFacus: false
    })
    let integer;
    for (let index in self.data.items){
      if (self.data.classifyName == self.data.items[index].name){
        integer=self.data.items[index].id
      }
    }
    self.setData({
      integer: integer,
      classifyNames: self.data.classifyName,
    })
  },
  cancelBtn:function(){
    let self = this;
    self.setData({
      classifys: true
    })
  },
  nameInput:function(e){
    let self = this;
    self.setData({
      nameContent:e.detail.value
    })
  },
  workInput:function(e){
    let self = this;
    self.setData({
      workContent: e.detail.value
    })
  },
  phoneInput:function(e){
    let self = this;
    self.setData({
      poneContent: e.detail.value
    })
  },
  wechatInput:function(e){
    let self = this;
    self.setData({
      wechatContent: e.detail.value
    })
  },
  nicknameInput:function(e){
    let self = this;
    self.setData({
      nicknameContent: e.detail.value
    })
  },
  descInput:function(e){
    let self = this;
    self.setData({
      descContent: e.detail.value
    })
  },
  submit:function(){
    let self = this;
    var myreg = /^[1][0-9]{10}$/;//手机号正则判断
    if (self.data.classifyNames == '') {
      wx.showToast({
        title: '请选择类型',
        icon:'none'
      })
      return
    }
    if (self.data.nameContent == ''){
      wx.showToast({
        title: '企业名不能为空',
        icon: 'none'
      })
      return
    }
    if (self.data.workContent == '') {
      wx.showToast({
        title: '职位不能为空',
        icon: 'none'
      })
      return
    }
    if (self.data.poneContent == '' || !myreg.test(self.data.poneContent)) {
      wx.showToast({
        title: '电话不正确',
        icon: 'none'
      })
      return
    }
    if (self.data.wechatContent == '') {
      wx.showToast({
        title: '微信不能为空',
        icon: 'none'
      })
      return
    }
    if (self.data.nicknameContent == '') {
      wx.showToast({
        title: '花名不能为空',
        icon: 'none'
      })
      return
    }
    let params={
      "entry": {
        "examineType": self.data.integer,
        "examineName": self.data.nameContent,
        "examinePosition": self.data.workContent,
        "examineMobile": self.data.poneContent,
        "examineWeChat": self.data.wechatContent,
        "examineFlowerName": self.data.nicknameContent,
        "examineDesc": self.data.descContent,
      }
    }
    console.log(params)
    util._request('/dabohui/member/enter', params, 'post').then(res => {
      if (res.code == 0) {
        wx.showToast({
          title: '提交成功',
        })
        self.setData({
          disabledData:true
        })
        wx.navigateBack({  
        })
      }else{
        wx.showToast({
          title: res.message,
          icon:'none'
        })
      }
    }).catch(e => {})
  },
  // 分享
  onShareAppMessage: function (res) {
    var that = this;
    return app.appShare();
  },
})