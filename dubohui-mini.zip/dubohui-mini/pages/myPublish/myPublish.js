
//index.js
//获取应用实例
const util = require("../../utils/api.js");
const app = getApp()
const times = require("../../utils/times.js")
Page({
  data: {
    navbar: ['动态', '解惑'],
    currentTab: 0,
    followResult: [],
    page: 1,
    totalPage: 0, 
    problemResult: [],
    top:0,
    pubIdArr: [],
    shareReturn: 0,
    isPlayState: true,
    videoSrc: '',
    videoContext: null,
    lock: false
  },
  onLoad: function (option) {
    let self = this;
    self.setData({
      top: app.globalData.titleBarHeight + app.globalData.statusBarHeight
    })
    self.refreshView = self.selectComponent("#refreshView");
    if (!app.token) {
      self.selectComponent("#login").showLogin();
    }
    self.myPublishList(true, false);
    this.shareBtn()
  },
  onShow:function(){
    let self = this;
    if (self.data.followResult && self.data.followResult.length > 0) {
      let allData = self.data.followResult
      for (let index in allData) {
        let startAt = allData[index].startAt;
        let timeStamp = times.timeStamps(startAt);
        allData[index].srartAtTimes = times.friendlyDate(timeStamp);
      }
      self.setData({
        followResult: allData
      })
    }
    if (self.data.problemResult && self.data.problemResult.length > 0) {
      let allData = self.data.problemResult
      for (let index in allData) {
        let startAt = allData[index].startAt;
        let timeStamp = times.timeStamps(startAt);
        allData[index].srartAtTimes = times.friendlyDate(timeStamp);
      }
      self.setData({
        problemResult: allData
      })
    }
    
  },
  // 我的发布
  myPublishList: function (pullDown = false, reachBottom = false) {
    let self = this;
    // 我的发布动态
    let params = {
      "inEntry": {
        "pubType": 0
      },
      "page": {
        "pageSize": 20,
        "pageNum": self.data.page,
        "sortBy": 1
      }
    }
    util._request('/dabohui/content/publishUser', params, 'post').then(res => {
      // console.log(JSON.stringify(res))
      if (res.code == 0) {
        self.data.totalPage = res.preload.totalPageNum
        let followResult = res.preload.results;
        
        // 日期转时间戳
        let pubArr = [];
        for (let index in followResult) {
          let startAt = followResult[index].startAt;
          let timeStamp = times.timeStamps(startAt);
          followResult[index].srartAtTimes = times.friendlyDate(timeStamp);
          let avatar = followResult[index].userInfo.avatar;
          if (avatar == '') {
            followResult[index].userInfo.avatar = "../../image/head.png"
          }
          let pubId = followResult[index].pubDetail.pubId;
          pubArr.push(pubId)
        }
        if (pullDown) {//执行的是下拉
          self.endThePullRequest()//结束下拉刷新
          self.setData({
            followResult: followResult,
            pubIdArr: pubArr
          })
        } else {//执行的是上拉.
          self.setData({
            followResult: self.data.followResult.concat(followResult),
            pubIdArr: pubArr
          })
        }  
      } else if (res.code == -1) {
        if (pullDown) {
          self.endThePullRequest()
        }
        self.dealTheCurrentPage()
        app.reInitData()
      } else {
        if (pullDown) {
          self.endThePullRequest()
        }
        self.dealTheCurrentPage()
      }
    }).catch(e => {
      if (pullDown) {
        self.endThePullRequest()
      }
      self.dealTheCurrentPage()
    });
  },
  //我的问题
  myProblemList: function (pullDowns = false, reachBottoms = false) {
    let self = this;
    //我的发布问题
    let paramsPro = {
      "inEntry": {
        "pubType": 1
      },
      "page": {
        "pageSize":20,
        "pageNum": self.data.page,
        "sortBy": 1
      }
    }
    util._request('/dabohui/content/publishUser', paramsPro, 'post').then(res => {
      if (res.code == 0) {
        self.data.totalPage = res.preload.totalPageNum
        let problemResult = res.preload.results;

        // 日期转时间戳
        for (let index in problemResult) {
          let startAt = problemResult[index].startAt;
          let timeStamp = times.timeStamps(startAt);
          problemResult[index].srartAtTimes = times.friendlyDate(timeStamp);
          let avatar = problemResult[index].userInfo.avatar;
          if (avatar == '') {
            problemResult[index].userInfo.avatar = "../../image/head.png"
          }
        }
        if (pullDowns) {//执行的是下拉
          self.endThePullRequest()//结束下拉刷新
          self.setData({
            problemResult: problemResult
          })
        } else {
          self.setData({
            problemResult: self.data.problemResult.concat(problemResult)
          })
        }
      } else if (res.code == -1) {
        self.dealTheCurrentPage()
        app.reInitData()
        if (pullDowns) {
          self.endThePullRequest()
        }
      } else {
        self.dealTheCurrentPage()
        if (pullDowns) {
          self.endThePullRequest()
        }
      }
    }).catch(e => {
      self.dealTheCurrentPage()
      if (pullDowns) {
        self.endThePullRequest()
      }
    })
  },
  //结束下拉刷新相关操作
  endThePullRequest() {
    this.refreshView.stopPullRefresh();
  },
  //请求出错的时候，要对page-1
  dealTheCurrentPage() {
    let that = this
    that.data.page--;
    if (that.data.page <= 0) {
      that.data.page = 1;
    }
  },
  // 下拉刷新
  onPullDownRefresh: function () {
    let that = this;
    that.data.page = 1;
    switch (that.data.currentTab) {
      case 0:
        that.myPublishList(true, false);
        break;
      default:
        that.myProblemList(true, false);
        break;
    }
  },
  //上拉加载
  onReachBottom() {
    let that = this
    if (that.data.totalPage > that.data.totalPageNum) {
      return;
    }
    that.data.page++;
    //首先判断是加载更多分类数据还是无分类的数
    switch(that.data.currentTab) {
      case 0:
        that.myPublishList(false, true);
      break;
      default: 
        that.myProblemList(false, true);
      break;
    } 
  },
  navbarTap: function (e) { 
    this.data.page = 1
    this.setData({
      currentTab: e.currentTarget.dataset.idx
    })
    switch (this.data.currentTab) {
      case 0:
        this.myPublishList(true, false);
        break;
      default:
        this.myProblemList(true, false);
        break;
    } 
  },
  // 点赞
  thumbs_up: function (e) {
    let self = this;
    let index = e.currentTarget.dataset.index;
    let followResult = self.data.followResult;
    for (let i in followResult) {
      if (i == index) {
        if (followResult[i].pubDetail.isPraise == 0) {
          let params = {
            "inEntry": {
              "bizId": e.currentTarget.dataset.pubid,
              "bizType": 0,
              "praiseType": true
            }
          }
          util._request('/content/comment/praise', params, 'post').then(res => {
            if (res.code == 0) {
              followResult[i].pubDetail.praiseNum += 1;
              followResult[i].pubDetail.isPraise = 1;
              self.setData({
                followResult: followResult
              })
            } else if (res.code == 1) {
              wx.showModal({
                title: '提示',
                content: res.message,
              })
            }
          }).catch(e => {
          })
        } else {
          let params = {
            "inEntry": {
              "bizId": e.currentTarget.dataset.pubid,
              "bizType": 0,
              "praiseType": false
            }
          }
          util._request('/content/comment/praise', params, 'post').then(res => {
            if (res.code == 0) {
              if (followResult[i].pubDetail.praiseNum == 0) {
                followResult[i].pubDetail.praiseNum = 0
              } else {
                followResult[i].pubDetail.praiseNum -= 1;
              }
              followResult[i].pubDetail.isPraise = 0;
              self.setData({
                followResult: followResult
              })
            } else if (res.code == 1) {
              wx.showModal({
                title: '提示',
                content: res.message,
              })
            }
          }).catch(e => {
          })
        }
      }
    }
  },
  // 页面跳转
  dynamicClick: function (e) {
    if (this.data.lock) {
      return;
    }
    let pubId = e.currentTarget.dataset.dx.pubId;
    // let itemString = JSON.stringify(item)
    wx.navigateTo({
      url: '../dynamic/dynamic?pubId=' + pubId
    })
  },
  dynamicList: function (e) {
    if (this.data.lock) {
      return;
    }
    let pubId = e.currentTarget.dataset.dx.pubId;
    // let itemString = JSON.stringify(item)
    wx.navigateTo({
      url: '../dynamic/dynamic?pubId=' + pubId
    })
  },
  problemClick: function (e) {
    if (this.data.lock) {
      return;
    }
    // let itemString = JSON.stringify(e.currentTarget.dataset);
    let pubId = e.currentTarget.dataset.datalist.pubId;
    wx.navigateTo({
      url: '../problemDetail/problemDetail?pubId=' + pubId,
    })
  },
  //删除
  cancelContent: function (e) {
    let self = this;
    wx.showModal({
      title: '提示',
      content: '您是否要删除该条信息',
      cancelText: "取消",
      cancelColor: "#000",
      confirmText: "确定",
      confirmColor: "#000",
      success: function (res) {
        if (res.confirm) {
          let params = {
            "bizId": e.currentTarget.dataset.pubid
          }
          util._request('/content/publish/delete', params, 'post').then(res => {
            if (res.code == 0) {
              wx.showToast({
                title: '删除成功',
                icon: 'none'
              })
              switch(self.data.currentTab) {
                case 0:
                  self.data.followResult.splice(e.currentTarget.dataset.index, 1);
                  self.setData({
                    followResult: self.data.followResult
                  })
                break;
                default:
                  self.data.problemResult.splice(e.currentTarget.dataset.index, 1);
                  self.setData({
                    problemResult: self.data.problemResult
                  })
                break;
              }
            }
          }).catch(e => {
            console.log(e)
          })
        } else {
        }
      }
    })
  },
  previewImg: function (e) {
    let pubIndex = e.currentTarget.dataset.pubindex;
    var index = e.currentTarget.dataset.index;
    let item = this.data.followResult[pubIndex];
    let imageUrls = item.pubDetail.extend.photos;
    var arr = []
    for (let index in imageUrls) {
      let imgUrllist = imageUrls[index].url;
      imgUrllist = imgUrllist.replace('!list', '!detail')
      arr.push(imgUrllist)
    }
    wx.previewImage({
      current: imageUrls[index].url.replace('!list', '!detail'),     //当前图片地址
      urls: arr,             //所有要预览的图片的地址集合 数组形式
      success: function (res) { },
      fail: function (res) { },
      complete: function (res) { },
    })
  },
  // 分享
  onShareAppMessage: function (res) {
    var that = this;
    let pubid = res.target.dataset.pubid;
    if (res.from === 'button') {
        let params = {
          "bizIds": [pubid]
        }
        util._request('/content/publish/updateShare', params, 'post').then(res => {
          if (res.code == 0) {
            let followResult = that.data.followResult;
            for (let index in followResult) {
              if (followResult[index].pubId == pubid) {
                followResult[index].pubDetail.shareNum += 1;
                break;
              }
            }
            that.setData({
              followResult: followResult
            })
          } else if (res.code == -1) {
          }
        }).catch(e => {//请求失败
        })
      return {
        title: "大播汇",
        path: "/pages/dynamic/dynamic?pubId=" + res.target.dataset.pubid + '&shareReturn=' + 1,
        success: function (a) {
          console.log(a)
        },
        fail: function (e) {
        }
      };
    } else if (res.from === 'menu') {
      return app.appShare();
    }
  },
  //触摸开始
  handletouchstart: function (event) {
    this.refreshView.handletouchstart(event)
  },
  //触摸移动
  handletouchmove: function (event) {
    this.refreshView.handletouchmove(event)
  },
  //触摸结束
  handletouchend: function (event) {
    this.refreshView.handletouchend(event)
  },
  //触摸取消
  handletouchcancel: function (event) {
    this.refreshView.handletouchcancel(event)
  },
  //页面滚动
  onPageScroll: function (event) {
    this.refreshView.onPageScroll(event)
  },
  shareBtn: function () {
    let self = this;
  },
  videoPlay: function (e) {
    let videoSrc = e.currentTarget.dataset.src;
    //跳转到全屏播放页面
    wx.navigateTo({
      url: '/pages/videoFull/videoFull?src=' + videoSrc,
    })
  },
  //长按复制
  copyContent: function (e) {
    // this.setData({
    //   lock: true
    // })
  }
})
