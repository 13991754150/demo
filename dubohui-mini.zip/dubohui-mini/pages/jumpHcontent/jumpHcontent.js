// pages/jumpHcontent/jumpHcontent.js
const app = getApp()
const util = require("../../utils/api.js")
Page({
  data: {
    bannerArr:''
  },
  onLoad(option){
    console.log(option)
    let self = this;
    self.setData({
      bannerArr: option.jumpLink
    })
    // util._request('/content/banner/list', params, 'post').then(res => {
    //   if (res.code == 0) {
    //     let bannerArr = res.preload.results;
    //     self.setData({
    //       bannerArr: bannerArr
    //     })
    //   }
    // }).catch(e => { })
  }
})
