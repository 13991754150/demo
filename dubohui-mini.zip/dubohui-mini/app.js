//app.js
App({
  globalData: {
    userInfo: null,
    basePath: 'https://do.comfire.cn',
    isIPX: false,
    videoHeight:0,  //定义视频的高度
    screenHeight: 0
  },
  //同步获取token
  token: wx.getStorageSync('userInfo').token,
  level: wx.getStorageSync('userInfo').level,
  //用户是否发布了新的发布，决定首页是否请求新的数据
  needHomeRequestData: false,
  //是否需要在关注页show的时候去请求数据
  needFollowRequestData: false,
  // 重置本地的用户信息
  reInitData() {
    let that = this
    that.token = null;
    that.globalData.userInfo = null
  },
  onShow:function(){
    //新版本更新提示
    this.getNewsFun() 
  },
  onLaunch: function (ops) {
    // 隐藏原生的tabbar
    let that = this;
    if (wx.canIUse('getUpdateManager')) {
      const updateManager = wx.getUpdateManager()
      updateManager.onCheckForUpdate(function (res) {
      if (res.hasUpdate) {
        updateManager.onUpdateReady(function () {
          wx.showModal({
            title: '更新提示',
            content: '新版本已经为您准备好，更多精彩等着你!',
            showCancel: false,
            success: function (res) {
              if (res.confirm) {
                updateManager.applyUpdate()
              }
            }
          })
        })
        updateManager.onUpdateFailed(function () {
          wx.showModal({
            title: '温馨提示',
            content: '新版本已经上线啦~，请您删除当前小程序，重新搜索打开哟~',
            showCancel: false,
          })
        })
      }
    })
    } else {
      wx.showModal({
        title: '提示',
        content: '当前微信版本过低，为了您的体验，请升级到最新微信版本后重试。',
        showCancel: false
      })
    }
    // 读取上一次的存储数据
    wx.getStorage({
      key: 'userInfo',
      success: function(res) {
        //如果存在上一次的存储数据的话，这时可以直接把数据保存到全局
        if(res.data){
          that.globalData.userInfo = res.data;
          that.token = that.globalData.userInfo.token;
          //同时发送一个静默请求，用来把获取到的最新的用户的信息上传给后台，且成功之后刷新本地全局
          wx.getUserInfo({
            success(res) {
              let params = {
                token: that.globalData.userInfo.token,
                timestamp: (new Date()).valueOf(),
                sign: '',
                tenant: 'dabohui',
                param: {
                  entry: {
                    nickname: res.userInfo.nickName,
                    avatar: res.userInfo.avatarUrl,
                    gender: res.userInfo.gender,
                    age: 0
                  }
                }
              }
              wx.request({
                url:that.globalData.basePath + '/member/_updateUser',
                data: params,
                method: 'post',
                header: {
                  'content-type': 'application/json'
                },
                success(res) {
                  if(res.data.code == 0){
                    // 存储数据
                    that.globalData.userInfo = {
                      nickname: res.data.preload.result.nickname,
                      gender: res.data.preload.result.gender,
                      avatar:res.data.preload.result.avatar,
                      age:res.data.preload.result.age,
                      userId: res.data.preload.result.userId,
                      token: that.globalData.userInfo.token,
                      level: res.data.preload.result.level
                    }
                  }else if(res.data.code == -1){//重置用户信息
                    that.reInitData()
                  }    
                },
              })
            }
          })
        }else{
        }   
      },
      fail:function(){//获取本地存储失败
      }
      
    })
    //获取设备信息
    wx.getSystemInfo({
      success: function (res) {
        that.globalData.platform = res.platform
        that.globalData.statusBarHeight = res.statusBarHeight
        if (res.model.indexOf('iPhone') !== -1) {//ios
          if (res.model.indexOf('iPhone X') !== -1) {//是X
            that.globalData.isIPX = true;
          }
          that.globalData.titleBarHeight = 44;
          that.globalData.screenHeight = res.screenHeight;
        } else {
          that.globalData.titleBarHeight = 48;
          that.globalData.screenHeight = res.screenHeight;
        } 
      },
      failure() {
        that.globalData.statusBarHeight = 0
        that.globalData.titleBarHeight = 0
      }
    })  
   
  },
  appShare: function () {
    return {
      title: "大播汇",
      path: "/pages/index/index",
      imageUrl:'/image/share.png',
      success: function (a) {
      },
      fail:function(e){    
      }
    };
  },
  //获取消息个数
  getNewsFun:function(){
    let that = this;
    let params = {
      token: wx.getStorageSync('userInfo').token,
      timestamp: (new Date()).valueOf(),
      sign: '',
      tenant: 'dabohui',
      param: {
      }
    }
    wx.request({
      url: that.globalData.basePath + '/message/_messageUnreadQuantity',
      data: params,
      method: 'post',
      header: {
        'content-type': 'application/json'
      },
      success(res) {
        if (res.data.code == 0) {
          let unreadQuantity = res.data.preload.result.unreadQuantity;
          if (unreadQuantity > 0) {
            wx.setTabBarBadge({
              index: 4,   //代表哪个tabbar（从0开始）
              text: String(unreadQuantity)
            })
          }else{
            wx.removeTabBarBadge({//这个方法为移除当前tabbar右上角的文本
              index: 4,		 //代表哪个tabbar（从0开始）
            })
          }
        } 
      },
    })
  }
})