const app = getApp()
// 请求封装「type对应not_need的时候，不需要传」
const _request = (url, params = {}, method = 'post', loading = '正在加载') => {
  let loadingTimer = 0;
  if (loading !== false) {
    wx.showLoading({
      title: loading,
      mask: true
    })
  }
  let data = {
    token: app.token,
    timestamp: (new Date()).valueOf(),
    sign: '',
    tenant: 'dabohui'
  }
  data.param = params
  let promise = new Promise((resolve, reject) => {
    // method = method.toUpperCase();
    wx.showLoading({
      title: 'loading...',
    })
    wx.request({
      // url: 'https://do.comfire.cn?group=dev',
      url: `${app.globalData.basePath}${url}`,
      data,
      method: method,
      header: {
        'content-type': 'application/json'
      },
      success(res) {
        wx.hideLoading();
        resolve(res.data);
        clearTimeout(loadingTimer);
        // if (res.data.code == -1) {//如果是-1情况，这个是清空本地的用户信息，然后提示用户登录失效
        //   app.globalData.userInfo = {}
        // } else {
        //   resolve(res.data);
        //   clearTimeout(loadingTimer);
        // }
      },
      fail(res) {
        reject(res);
        wx.showToast({
          title: '请求失败！',
          icon: 'fail',
          duration: 2000
        })
        wx.hideLoading();
      }
    })
  });
  return promise;
}
module.exports = {
  _request
}