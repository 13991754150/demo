module.exports = [
  {
    "pagePath": "pages/index/index",
    "text": "首页",
    "iconPath": "../../image/index.png",
    "selectedIconPath": "../../image/shuaxin.png",
    "auth": 0
  },
  {
    "pagePath": "pages/follow/follow",
    "text": "关注",
    "iconPath": "../../image/guanzhu.png",
    "selectedIconPath": "../../image/follow@2x.png",
    "auth": 0
  },
  {
    "pagePath": "pages/publish/publish",
    "text": "发布",
    "iconPath": "../../image/publish@2x.png",
    "selectedIconPath": "../../image/publish1@2x.png",
    "auth": 0
  },
  {
    "pagePath": "pages/ansower/ansower",
    "text": "问答",
    "iconPath": "../../image/wenda.png",
    "selectedIconPath": "../../image/ansower@2x.png",
    "auth": 0
  },
  {
    "pagePath": "pages/personal/personal",
    "text": "个人",
    "iconPath": "../../image/person.png",
    "selectedIconPath": "../../image/person@2x.png",
    "auth": 0
  }
]