const util = require("../../utils/api.js")
const app = getApp()
Component({
  behaviors: [],
  properties: {
    myProperty: { // 属性名
      type: String, // 类型（必填），目前接受的类型包括：String, Number, Boolean, Object, Array, null（表示任意类型）
      value: '', // 属性初始值（可选），如果未指定则会根据类型选择一个
      observer(newVal, oldVal, changedPath) {  
      }
    },
    myProperty2: String // 简化的定义方式
  },
  data: {
    canIUse: wx.canIUse('button.open-type.getUserInfo'),
    flag: true,
    code:'',
    isClick:true
  }, // 私有数据，可用于模板渲染
methods: {
  onLoad:function(){
  },
  loginIn: function () {
    let that = this;
    if (that.data.isClick){
      that.data.isClick = false
      wx.showLoading({
        title: '加载中...',
      })
      wx.login({
        success: res => {//这里是微信一个bug，点击拒绝的时候依然能够获得用户的code
          // 发送 res.code 到后台换取 openId, sessionKey, unionId
          let params = {
            'entry': {
              'authCode': res.code,
              'requestFrom': 40,
              'requestVer': '1.0.0'
            }
          };
          if (!res.code) {
            return;
          }
          //请求注册接口注册用户
          util._request('/dabohui/member/wechatMini', params, 'post').then(res => {
            wx.hideLoading()
            if (res.code == 0) {
              this.setData({//组件隐藏
                flag: true
              })
              //保存到全局token
              app.token = res.preload.result.token
              // 获取用户信息
              wx.getUserInfo({
                success: function (res) {
                  var userInfo = res.userInfo;
                  let params = {
                    "entry": {
                      "nickname": userInfo.nickName,
                      "avatar": userInfo.avatarUrl,
                      "gender": userInfo.gender,
                      "age": 0
                    }
                  }
                  util._request('/member/_updateUser', params, 'post').then(res => {
                    if (res.code == 0) {
                      wx.showToast({
                        title: '登录成功',
                      })
                      that.setData({//组件隐藏
                        flag: true
                      })
                      app.globalData.userInfo = {
                        avatar: res.preload.result.avatar,
                        nickname: res.preload.result.nickname,
                        gender: res.preload.result.gender,
                        userId: res.preload.result.userId,
                        token: app.token,
                        level: res.preload.result.level
                      }
                      wx.setStorage({
                        key: 'userInfo',
                        data: app.globalData.userInfo,
                      })
                      that.triggerEvent("myevent", { loginSuccess: true })
                      wx.showToast({
                        title: '登录成功',
                      })
                    }

                  }).catch(e => {
                  })
                },
                fail: function (e) {
                  wx.showToast({
                    title: '微信授权失败',
                    icon: 'none'
                  })
                  app.reInitData()
                  that.showLogin()
                  console.log('获取用户信息失败，因为点击拒绝导致的错误，这里不予存储信息')
                }
              })
            } else {//返回code是非0的情况
              that.showLogin();
              wx.showToast({
                title: res.message,
                icon: 'none'
              })
            }
          }).catch(e => {//login失败
            console.log('请求微信login失败' + e.errMsg)
          })
        },
        fail: function (data) {
          that.showLogin()
        }
      })
      setTimeout(function(){
        that.data.isClick = true
      },1500)
    }
  },
  //隐藏弹框
  close: function () {
    this.setData({
      flag: true
    })
  },
  //展示弹框
  showLogin: function () {
    this.setData({
      flag: false
    })
  },
  }
})